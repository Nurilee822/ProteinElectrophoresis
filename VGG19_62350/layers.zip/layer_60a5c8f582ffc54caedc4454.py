import tensorflow.keras as keras


class Conv2D(keras.layers.Conv2D):
    pass