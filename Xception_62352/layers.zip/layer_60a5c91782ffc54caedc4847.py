from tensorflow.keras.layers import *


class GlobalAveragePooling2D(GlobalAveragePooling2D):
    pass