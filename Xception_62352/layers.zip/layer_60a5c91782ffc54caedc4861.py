from tensorflow.keras.layers import *


class SeparableConv2D(SeparableConv2D):
    pass