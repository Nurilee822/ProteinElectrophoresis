from tensorflow.keras.layers import *


class Dense(Dense):
    pass