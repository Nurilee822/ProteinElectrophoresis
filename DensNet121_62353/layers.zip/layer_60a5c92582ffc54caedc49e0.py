import tensorflow.keras as keras


class ZeroPadding2D(keras.layers.ZeroPadding2D):
    pass