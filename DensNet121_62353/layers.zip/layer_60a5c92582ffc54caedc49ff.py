from tensorflow.keras.layers import *


class Concatenate(Concatenate):
    pass