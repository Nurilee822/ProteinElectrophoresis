import sys
from tensorflow import keras
import tensorflow.keras.backend as K
import inspect
import os

file_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(f"{file_path}/layers")
sys.path.append(f"{file_path}/utils")


from base_model import BaseModel
from inspect import getmembers, isfunction

import tensorflow as tf
import layer_6059b49014bdf454a9de7534 as layer_6059b49014bdf454a9de7534
import layer_6059b49014bdf454a9de7538 as layer_6059b49014bdf454a9de7538
import layer_6059b49014bdf454a9de753c as layer_6059b49014bdf454a9de753c
import layer_6059b49014bdf454a9de753a as layer_6059b49014bdf454a9de753a
import layer_6059b49014bdf454a9de753e as layer_6059b49014bdf454a9de753e
import layer_6059b49014bdf454a9de7540 as layer_6059b49014bdf454a9de7540
import layer_6059b49014bdf454a9de7542 as layer_6059b49014bdf454a9de7542
import layer_6059b49014bdf454a9de7544 as layer_6059b49014bdf454a9de7544
import layer_6059b49014bdf454a9de7546 as layer_6059b49014bdf454a9de7546
import layer_6059b49014bdf454a9de7548 as layer_6059b49014bdf454a9de7548
import layer_6059b49014bdf454a9de754a as layer_6059b49014bdf454a9de754a
import layer_6059b49014bdf454a9de7588 as layer_6059b49014bdf454a9de7588
import layer_6059b49014bdf454a9de7550 as layer_6059b49014bdf454a9de7550
import layer_6059b49014bdf454a9de7554 as layer_6059b49014bdf454a9de7554
import layer_6059b49014bdf454a9de7558 as layer_6059b49014bdf454a9de7558
import layer_6059b49014bdf454a9de755c as layer_6059b49014bdf454a9de755c
import layer_6059b49014bdf454a9de7568 as layer_6059b49014bdf454a9de7568
import layer_6059b49014bdf454a9de756c as layer_6059b49014bdf454a9de756c
import layer_6059b49014bdf454a9de757e as layer_6059b49014bdf454a9de757e
import layer_6059b49014bdf454a9de7582 as layer_6059b49014bdf454a9de7582
import layer_6059b49014bdf454a9de7586 as layer_6059b49014bdf454a9de7586
import layer_6059b49014bdf454a9de7552 as layer_6059b49014bdf454a9de7552
import layer_6059b49014bdf454a9de755a as layer_6059b49014bdf454a9de755a
import layer_6059b49014bdf454a9de7560 as layer_6059b49014bdf454a9de7560
import layer_6059b49014bdf454a9de7564 as layer_6059b49014bdf454a9de7564
import layer_6059b49014bdf454a9de756a as layer_6059b49014bdf454a9de756a
import layer_6059b49014bdf454a9de7570 as layer_6059b49014bdf454a9de7570
import layer_6059b49014bdf454a9de7574 as layer_6059b49014bdf454a9de7574
import layer_6059b49014bdf454a9de7584 as layer_6059b49014bdf454a9de7584
import layer_6059b49014bdf454a9de7562 as layer_6059b49014bdf454a9de7562
import layer_6059b49014bdf454a9de7572 as layer_6059b49014bdf454a9de7572
import layer_6059b49014bdf454a9de7578 as layer_6059b49014bdf454a9de7578
import layer_6059b49014bdf454a9de757c as layer_6059b49014bdf454a9de757c
import layer_6059b49014bdf454a9de757a as layer_6059b49014bdf454a9de757a
import layer_6059b49014bdf454a9de758d as layer_6059b49014bdf454a9de758d
import layer_6059b49014bdf454a9de75cb as layer_6059b49014bdf454a9de75cb
import layer_6059b49014bdf454a9de7593 as layer_6059b49014bdf454a9de7593
import layer_6059b49014bdf454a9de7597 as layer_6059b49014bdf454a9de7597
import layer_6059b49014bdf454a9de759b as layer_6059b49014bdf454a9de759b
import layer_6059b49014bdf454a9de759f as layer_6059b49014bdf454a9de759f
import layer_6059b49014bdf454a9de75ab as layer_6059b49014bdf454a9de75ab
import layer_6059b49014bdf454a9de75af as layer_6059b49014bdf454a9de75af
import layer_6059b49014bdf454a9de75c1 as layer_6059b49014bdf454a9de75c1
import layer_6059b49014bdf454a9de75c5 as layer_6059b49014bdf454a9de75c5
import layer_6059b49014bdf454a9de75c9 as layer_6059b49014bdf454a9de75c9
import layer_6059b49014bdf454a9de7595 as layer_6059b49014bdf454a9de7595
import layer_6059b49014bdf454a9de759d as layer_6059b49014bdf454a9de759d
import layer_6059b49014bdf454a9de75a3 as layer_6059b49014bdf454a9de75a3
import layer_6059b49014bdf454a9de75a7 as layer_6059b49014bdf454a9de75a7
import layer_6059b49014bdf454a9de75ad as layer_6059b49014bdf454a9de75ad
import layer_6059b49014bdf454a9de75b3 as layer_6059b49014bdf454a9de75b3
import layer_6059b49014bdf454a9de75b7 as layer_6059b49014bdf454a9de75b7
import layer_6059b49014bdf454a9de75c7 as layer_6059b49014bdf454a9de75c7
import layer_6059b49014bdf454a9de75a5 as layer_6059b49014bdf454a9de75a5
import layer_6059b49014bdf454a9de75b5 as layer_6059b49014bdf454a9de75b5
import layer_6059b49014bdf454a9de75bb as layer_6059b49014bdf454a9de75bb
import layer_6059b49014bdf454a9de75bf as layer_6059b49014bdf454a9de75bf
import layer_6059b49014bdf454a9de75bd as layer_6059b49014bdf454a9de75bd
import layer_6059b49014bdf454a9de75d0 as layer_6059b49014bdf454a9de75d0
import layer_6059b49014bdf454a9de760e as layer_6059b49014bdf454a9de760e
import layer_6059b49014bdf454a9de75d6 as layer_6059b49014bdf454a9de75d6
import layer_6059b49014bdf454a9de75da as layer_6059b49014bdf454a9de75da
import layer_6059b49014bdf454a9de75de as layer_6059b49014bdf454a9de75de
import layer_6059b49014bdf454a9de75e2 as layer_6059b49014bdf454a9de75e2
import layer_6059b49014bdf454a9de75ee as layer_6059b49014bdf454a9de75ee
import layer_6059b49014bdf454a9de75f2 as layer_6059b49014bdf454a9de75f2
import layer_6059b49014bdf454a9de7604 as layer_6059b49014bdf454a9de7604
import layer_6059b49014bdf454a9de7608 as layer_6059b49014bdf454a9de7608
import layer_6059b49014bdf454a9de760c as layer_6059b49014bdf454a9de760c
import layer_6059b49014bdf454a9de75d8 as layer_6059b49014bdf454a9de75d8
import layer_6059b49014bdf454a9de75e0 as layer_6059b49014bdf454a9de75e0
import layer_6059b49014bdf454a9de75e6 as layer_6059b49014bdf454a9de75e6
import layer_6059b49014bdf454a9de75ea as layer_6059b49014bdf454a9de75ea
import layer_6059b49014bdf454a9de75f0 as layer_6059b49014bdf454a9de75f0
import layer_6059b49014bdf454a9de75f6 as layer_6059b49014bdf454a9de75f6
import layer_6059b49014bdf454a9de75fa as layer_6059b49014bdf454a9de75fa
import layer_6059b49014bdf454a9de760a as layer_6059b49014bdf454a9de760a
import layer_6059b49014bdf454a9de75e8 as layer_6059b49014bdf454a9de75e8
import layer_6059b49014bdf454a9de75f8 as layer_6059b49014bdf454a9de75f8
import layer_6059b49014bdf454a9de75fe as layer_6059b49014bdf454a9de75fe
import layer_6059b49014bdf454a9de7602 as layer_6059b49014bdf454a9de7602
import layer_6059b49014bdf454a9de7600 as layer_6059b49014bdf454a9de7600
import layer_6059b49014bdf454a9de7613 as layer_6059b49014bdf454a9de7613
import layer_6059b49014bdf454a9de761f as layer_6059b49014bdf454a9de761f
import layer_6059b49014bdf454a9de7623 as layer_6059b49014bdf454a9de7623
import layer_6059b49014bdf454a9de7625 as layer_6059b49014bdf454a9de7625
import layer_6059b49014bdf454a9de7627 as layer_6059b49014bdf454a9de7627
import layer_6059b49014bdf454a9de762b as layer_6059b49014bdf454a9de762b
import layer_6059b49014bdf454a9de762d as layer_6059b49014bdf454a9de762d
import layer_6059b49014bdf454a9de762f as layer_6059b49014bdf454a9de762f
import layer_6059b49014bdf454a9de7633 as layer_6059b49014bdf454a9de7633
import layer_6059b49014bdf454a9de7635 as layer_6059b49014bdf454a9de7635
import layer_6059b49014bdf454a9de7637 as layer_6059b49014bdf454a9de7637
import layer_6059b49014bdf454a9de7639 as layer_6059b49014bdf454a9de7639
import layer_6059b49014bdf454a9de7619 as layer_6059b49014bdf454a9de7619
import layer_6059b49014bdf454a9de761b as layer_6059b49014bdf454a9de761b
import layer_6059b49014bdf454a9de761d as layer_6059b49014bdf454a9de761d
import layer_6059b49014bdf454a9de763d as layer_6059b49014bdf454a9de763d
import layer_6059b49014bdf454a9de7671 as layer_6059b49014bdf454a9de7671
import layer_6059b49014bdf454a9de7643 as layer_6059b49014bdf454a9de7643
import layer_6059b49014bdf454a9de7647 as layer_6059b49014bdf454a9de7647
import layer_6059b49014bdf454a9de764b as layer_6059b49014bdf454a9de764b
import layer_6059b49014bdf454a9de764f as layer_6059b49014bdf454a9de764f
import layer_6059b49014bdf454a9de7661 as layer_6059b49014bdf454a9de7661
import layer_6059b49014bdf454a9de7665 as layer_6059b49014bdf454a9de7665
import layer_6059b49014bdf454a9de7667 as layer_6059b49014bdf454a9de7667
import layer_6059b49014bdf454a9de766b as layer_6059b49014bdf454a9de766b
import layer_6059b49014bdf454a9de766f as layer_6059b49014bdf454a9de766f
import layer_6059b49014bdf454a9de7645 as layer_6059b49014bdf454a9de7645
import layer_6059b49014bdf454a9de764d as layer_6059b49014bdf454a9de764d
import layer_6059b49014bdf454a9de7653 as layer_6059b49014bdf454a9de7653
import layer_6059b49014bdf454a9de7657 as layer_6059b49014bdf454a9de7657
import layer_6059b49014bdf454a9de7663 as layer_6059b49014bdf454a9de7663
import layer_6059b49014bdf454a9de766d as layer_6059b49014bdf454a9de766d
import layer_6059b49014bdf454a9de767a as layer_6059b49014bdf454a9de767a
import layer_6059b49014bdf454a9de767e as layer_6059b49014bdf454a9de767e
import layer_6059b49014bdf454a9de7655 as layer_6059b49014bdf454a9de7655
import layer_6059b49014bdf454a9de7659 as layer_6059b49014bdf454a9de7659
import layer_6059b49014bdf454a9de765b as layer_6059b49014bdf454a9de765b
import layer_6059b49014bdf454a9de765d as layer_6059b49014bdf454a9de765d
import layer_6059b49014bdf454a9de767c as layer_6059b49014bdf454a9de767c
import layer_6059b49014bdf454a9de7680 as layer_6059b49014bdf454a9de7680
import layer_6059b49014bdf454a9de7682 as layer_6059b49014bdf454a9de7682
import layer_6059b49014bdf454a9de7684 as layer_6059b49014bdf454a9de7684
import layer_6059b49014bdf454a9de7688 as layer_6059b49014bdf454a9de7688
import layer_6059b49014bdf454a9de768c as layer_6059b49014bdf454a9de768c
import layer_6059b49014bdf454a9de768a as layer_6059b49014bdf454a9de768a
import layer_6059b49014bdf454a9de768e as layer_6059b49014bdf454a9de768e
import layer_6059b49014bdf454a9de7690 as layer_6059b49014bdf454a9de7690
import layer_6059b49014bdf454a9de7692 as layer_6059b49014bdf454a9de7692
import layer_6059b49014bdf454a9de7676 as layer_6059b49014bdf454a9de7676
import layer_6059b49014bdf454a9de76c6 as layer_6059b49014bdf454a9de76c6
import layer_6059b49014bdf454a9de7698 as layer_6059b49014bdf454a9de7698
import layer_6059b49014bdf454a9de769c as layer_6059b49014bdf454a9de769c
import layer_6059b49014bdf454a9de76a0 as layer_6059b49014bdf454a9de76a0
import layer_6059b49014bdf454a9de76a4 as layer_6059b49014bdf454a9de76a4
import layer_6059b49014bdf454a9de76b6 as layer_6059b49014bdf454a9de76b6
import layer_6059b49014bdf454a9de76ba as layer_6059b49014bdf454a9de76ba
import layer_6059b49014bdf454a9de76bc as layer_6059b49014bdf454a9de76bc
import layer_6059b49014bdf454a9de76c0 as layer_6059b49014bdf454a9de76c0
import layer_6059b49014bdf454a9de76c4 as layer_6059b49014bdf454a9de76c4
import layer_6059b49014bdf454a9de769a as layer_6059b49014bdf454a9de769a
import layer_6059b49014bdf454a9de76a2 as layer_6059b49014bdf454a9de76a2
import layer_6059b49014bdf454a9de76a8 as layer_6059b49014bdf454a9de76a8
import layer_6059b49014bdf454a9de76ac as layer_6059b49014bdf454a9de76ac
import layer_6059b49014bdf454a9de76b8 as layer_6059b49014bdf454a9de76b8
import layer_6059b49014bdf454a9de76c2 as layer_6059b49014bdf454a9de76c2
import layer_6059b49014bdf454a9de76cf as layer_6059b49014bdf454a9de76cf
import layer_6059b49014bdf454a9de76d3 as layer_6059b49014bdf454a9de76d3
import layer_6059b49014bdf454a9de76aa as layer_6059b49014bdf454a9de76aa
import layer_6059b49014bdf454a9de76ae as layer_6059b49014bdf454a9de76ae
import layer_6059b49014bdf454a9de76b0 as layer_6059b49014bdf454a9de76b0
import layer_6059b49014bdf454a9de76b2 as layer_6059b49014bdf454a9de76b2
import layer_6059b49014bdf454a9de76d1 as layer_6059b49014bdf454a9de76d1
import layer_6059b49014bdf454a9de76d5 as layer_6059b49014bdf454a9de76d5
import layer_6059b49014bdf454a9de76d7 as layer_6059b49014bdf454a9de76d7
import layer_6059b49014bdf454a9de76d9 as layer_6059b49014bdf454a9de76d9
import layer_6059b49014bdf454a9de76dd as layer_6059b49014bdf454a9de76dd
import layer_6059b49014bdf454a9de76e1 as layer_6059b49014bdf454a9de76e1
import layer_6059b49014bdf454a9de76df as layer_6059b49014bdf454a9de76df
import layer_6059b49014bdf454a9de76e3 as layer_6059b49014bdf454a9de76e3
import layer_6059b49014bdf454a9de76e5 as layer_6059b49014bdf454a9de76e5
import layer_6059b49014bdf454a9de76e7 as layer_6059b49014bdf454a9de76e7
import layer_6059b49014bdf454a9de76cb as layer_6059b49014bdf454a9de76cb
import layer_6059b49014bdf454a9de7770 as layer_6059b49014bdf454a9de7770
import layer_6059b49014bdf454a9de7742 as layer_6059b49014bdf454a9de7742
import layer_6059b49014bdf454a9de7746 as layer_6059b49014bdf454a9de7746
import layer_6059b49014bdf454a9de774a as layer_6059b49014bdf454a9de774a
import layer_6059b49014bdf454a9de774e as layer_6059b49014bdf454a9de774e
import layer_6059b49014bdf454a9de7760 as layer_6059b49014bdf454a9de7760
import layer_6059b49014bdf454a9de7764 as layer_6059b49014bdf454a9de7764
import layer_6059b49014bdf454a9de7766 as layer_6059b49014bdf454a9de7766
import layer_6059b49014bdf454a9de776a as layer_6059b49014bdf454a9de776a
import layer_6059b49014bdf454a9de776e as layer_6059b49014bdf454a9de776e
import layer_6059b49014bdf454a9de7744 as layer_6059b49014bdf454a9de7744
import layer_6059b49014bdf454a9de774c as layer_6059b49014bdf454a9de774c
import layer_6059b49014bdf454a9de7752 as layer_6059b49014bdf454a9de7752
import layer_6059b49014bdf454a9de7756 as layer_6059b49014bdf454a9de7756
import layer_6059b49014bdf454a9de7762 as layer_6059b49014bdf454a9de7762
import layer_6059b49014bdf454a9de776c as layer_6059b49014bdf454a9de776c
import layer_6059b49014bdf454a9de7779 as layer_6059b49014bdf454a9de7779
import layer_6059b49014bdf454a9de777d as layer_6059b49014bdf454a9de777d
import layer_6059b49014bdf454a9de7754 as layer_6059b49014bdf454a9de7754
import layer_6059b49014bdf454a9de7758 as layer_6059b49014bdf454a9de7758
import layer_6059b49014bdf454a9de775a as layer_6059b49014bdf454a9de775a
import layer_6059b49014bdf454a9de775c as layer_6059b49014bdf454a9de775c
import layer_6059b49014bdf454a9de777b as layer_6059b49014bdf454a9de777b
import layer_6059b49014bdf454a9de777f as layer_6059b49014bdf454a9de777f
import layer_6059b49014bdf454a9de7781 as layer_6059b49014bdf454a9de7781
import layer_6059b49014bdf454a9de7783 as layer_6059b49014bdf454a9de7783
import layer_6059b49014bdf454a9de7787 as layer_6059b49014bdf454a9de7787
import layer_6059b49014bdf454a9de778b as layer_6059b49014bdf454a9de778b
import layer_6059b49014bdf454a9de7789 as layer_6059b49014bdf454a9de7789
import layer_6059b49014bdf454a9de778d as layer_6059b49014bdf454a9de778d
import layer_6059b49014bdf454a9de778f as layer_6059b49014bdf454a9de778f
import layer_6059b49014bdf454a9de7791 as layer_6059b49014bdf454a9de7791
import layer_6059b49014bdf454a9de7775 as layer_6059b49014bdf454a9de7775
import layer_6059b49014bdf454a9de771b as layer_6059b49014bdf454a9de771b
import layer_6059b49014bdf454a9de76ed as layer_6059b49014bdf454a9de76ed
import layer_6059b49014bdf454a9de76f1 as layer_6059b49014bdf454a9de76f1
import layer_6059b49014bdf454a9de76f5 as layer_6059b49014bdf454a9de76f5
import layer_6059b49014bdf454a9de76f9 as layer_6059b49014bdf454a9de76f9
import layer_6059b49014bdf454a9de770b as layer_6059b49014bdf454a9de770b
import layer_6059b49014bdf454a9de770f as layer_6059b49014bdf454a9de770f
import layer_6059b49014bdf454a9de7711 as layer_6059b49014bdf454a9de7711
import layer_6059b49014bdf454a9de7715 as layer_6059b49014bdf454a9de7715
import layer_6059b49014bdf454a9de7719 as layer_6059b49014bdf454a9de7719
import layer_6059b49014bdf454a9de76ef as layer_6059b49014bdf454a9de76ef
import layer_6059b49014bdf454a9de76f7 as layer_6059b49014bdf454a9de76f7
import layer_6059b49014bdf454a9de76fd as layer_6059b49014bdf454a9de76fd
import layer_6059b49014bdf454a9de7701 as layer_6059b49014bdf454a9de7701
import layer_6059b49014bdf454a9de770d as layer_6059b49014bdf454a9de770d
import layer_6059b49014bdf454a9de7717 as layer_6059b49014bdf454a9de7717
import layer_6059b49014bdf454a9de7724 as layer_6059b49014bdf454a9de7724
import layer_6059b49014bdf454a9de7728 as layer_6059b49014bdf454a9de7728
import layer_6059b49014bdf454a9de76ff as layer_6059b49014bdf454a9de76ff
import layer_6059b49014bdf454a9de7703 as layer_6059b49014bdf454a9de7703
import layer_6059b49014bdf454a9de7705 as layer_6059b49014bdf454a9de7705
import layer_6059b49014bdf454a9de7707 as layer_6059b49014bdf454a9de7707
import layer_6059b49014bdf454a9de7726 as layer_6059b49014bdf454a9de7726
import layer_6059b49014bdf454a9de772a as layer_6059b49014bdf454a9de772a
import layer_6059b49014bdf454a9de772c as layer_6059b49014bdf454a9de772c
import layer_6059b49014bdf454a9de772e as layer_6059b49014bdf454a9de772e
import layer_6059b49014bdf454a9de7732 as layer_6059b49014bdf454a9de7732
import layer_6059b49014bdf454a9de7736 as layer_6059b49014bdf454a9de7736
import layer_6059b49014bdf454a9de7734 as layer_6059b49014bdf454a9de7734
import layer_6059b49014bdf454a9de7738 as layer_6059b49014bdf454a9de7738
import layer_6059b49014bdf454a9de773a as layer_6059b49014bdf454a9de773a
import layer_6059b49014bdf454a9de773c as layer_6059b49014bdf454a9de773c
import layer_6059b49014bdf454a9de7720 as layer_6059b49014bdf454a9de7720
import layer_6059b49014bdf454a9de779d as layer_6059b49014bdf454a9de779d
import layer_6059b49014bdf454a9de77a1 as layer_6059b49014bdf454a9de77a1
import layer_6059b49014bdf454a9de77a3 as layer_6059b49014bdf454a9de77a3
import layer_6059b49014bdf454a9de77a5 as layer_6059b49014bdf454a9de77a5
import layer_6059b49014bdf454a9de77a9 as layer_6059b49014bdf454a9de77a9
import layer_6059b49014bdf454a9de77ab as layer_6059b49014bdf454a9de77ab
import layer_6059b49014bdf454a9de77ad as layer_6059b49014bdf454a9de77ad
import layer_6059b49014bdf454a9de77af as layer_6059b49014bdf454a9de77af
import layer_6059b49014bdf454a9de77b1 as layer_6059b49014bdf454a9de77b1
import layer_6059b49014bdf454a9de77b3 as layer_6059b49014bdf454a9de77b3
import layer_6059b49014bdf454a9de77b7 as layer_6059b49014bdf454a9de77b7
import layer_6059b49014bdf454a9de77b9 as layer_6059b49014bdf454a9de77b9
import layer_6059b49014bdf454a9de77bb as layer_6059b49014bdf454a9de77bb
import layer_6059b49014bdf454a9de77bd as layer_6059b49014bdf454a9de77bd
import layer_6059b49014bdf454a9de7797 as layer_6059b49014bdf454a9de7797
import layer_6059b49014bdf454a9de7799 as layer_6059b49014bdf454a9de7799
import layer_6059b49014bdf454a9de779b as layer_6059b49014bdf454a9de779b
import layer_6059b49014bdf454a9de77c5 as layer_6059b49014bdf454a9de77c5
import layer_6059b49014bdf454a9de77c7 as layer_6059b49014bdf454a9de77c7
import layer_6059b49014bdf454a9de77c9 as layer_6059b49014bdf454a9de77c9
import layer_6059b49014bdf454a9de77c1 as layer_6059b49014bdf454a9de77c1
import layer_6059b49014bdf454a9de77d5 as layer_6059b49014bdf454a9de77d5
import layer_6059b49014bdf454a9de77d9 as layer_6059b49014bdf454a9de77d9
import layer_6059b49014bdf454a9de77db as layer_6059b49014bdf454a9de77db
import layer_6059b49014bdf454a9de77dd as layer_6059b49014bdf454a9de77dd
import layer_6059b49014bdf454a9de77e1 as layer_6059b49014bdf454a9de77e1
import layer_6059b49014bdf454a9de77e3 as layer_6059b49014bdf454a9de77e3
import layer_6059b49014bdf454a9de77e5 as layer_6059b49014bdf454a9de77e5
import layer_6059b49014bdf454a9de77e9 as layer_6059b49014bdf454a9de77e9
import layer_6059b49014bdf454a9de77eb as layer_6059b49014bdf454a9de77eb
import layer_6059b49014bdf454a9de77ed as layer_6059b49014bdf454a9de77ed
import layer_6059b49014bdf454a9de77f0 as layer_6059b49014bdf454a9de77f0
import layer_6059b49014bdf454a9de77f4 as layer_6059b49014bdf454a9de77f4
import layer_6059b49014bdf454a9de77f6 as layer_6059b49014bdf454a9de77f6
import layer_6059b49014bdf454a9de77f8 as layer_6059b49014bdf454a9de77f8
import layer_6059b49014bdf454a9de77fc as layer_6059b49014bdf454a9de77fc
import layer_6059b49014bdf454a9de77fe as layer_6059b49014bdf454a9de77fe
import layer_6059b49014bdf454a9de7800 as layer_6059b49014bdf454a9de7800
import layer_6059b49014bdf454a9de7804 as layer_6059b49014bdf454a9de7804
import layer_6059b49014bdf454a9de7806 as layer_6059b49014bdf454a9de7806
import layer_6059b49014bdf454a9de7808 as layer_6059b49014bdf454a9de7808
import layer_6059b49014bdf454a9de780c as layer_6059b49014bdf454a9de780c
import layer_6059b49014bdf454a9de780e as layer_6059b49014bdf454a9de780e
import layer_6059b49014bdf454a9de7810 as layer_6059b49014bdf454a9de7810
import layer_6059b49014bdf454a9de7813 as layer_6059b49014bdf454a9de7813
import layer_6059b49014bdf454a9de7815 as layer_6059b49014bdf454a9de7815
import layer_6059b49014bdf454a9de7819 as layer_6059b49014bdf454a9de7819
import layer_6059b49014bdf454a9de781b as layer_6059b49014bdf454a9de781b
import layer_6059b49014bdf454a9de781d as layer_6059b49014bdf454a9de781d
import layer_6059b49014bdf454a9de77cf as layer_6059b49014bdf454a9de77cf
import layer_6059b49014bdf454a9de77d1 as layer_6059b49014bdf454a9de77d1
import layer_6059b49014bdf454a9de77d3 as layer_6059b49014bdf454a9de77d3
import layer_6059b49014bdf454a9de7822 as layer_6059b49014bdf454a9de7822
import layer_6059b49014bdf454a9de782e as layer_6059b49014bdf454a9de782e
import layer_6059b49014bdf454a9de7832 as layer_6059b49014bdf454a9de7832
import layer_6059b49014bdf454a9de7834 as layer_6059b49014bdf454a9de7834
import layer_6059b49014bdf454a9de7836 as layer_6059b49014bdf454a9de7836
import layer_6059b49014bdf454a9de783a as layer_6059b49014bdf454a9de783a
import layer_6059b49014bdf454a9de783c as layer_6059b49014bdf454a9de783c
import layer_6059b49014bdf454a9de783e as layer_6059b49014bdf454a9de783e
import layer_6059b49014bdf454a9de7842 as layer_6059b49014bdf454a9de7842
import layer_6059b49014bdf454a9de7844 as layer_6059b49014bdf454a9de7844
import layer_6059b49014bdf454a9de7846 as layer_6059b49014bdf454a9de7846
import layer_6059b49014bdf454a9de7849 as layer_6059b49014bdf454a9de7849
import layer_6059b49014bdf454a9de784d as layer_6059b49014bdf454a9de784d
import layer_6059b49014bdf454a9de784f as layer_6059b49014bdf454a9de784f
import layer_6059b49014bdf454a9de7851 as layer_6059b49014bdf454a9de7851
import layer_6059b49014bdf454a9de7855 as layer_6059b49014bdf454a9de7855
import layer_6059b49014bdf454a9de7857 as layer_6059b49014bdf454a9de7857
import layer_6059b49014bdf454a9de7859 as layer_6059b49014bdf454a9de7859
import layer_6059b49014bdf454a9de785d as layer_6059b49014bdf454a9de785d
import layer_6059b49014bdf454a9de785f as layer_6059b49014bdf454a9de785f
import layer_6059b49014bdf454a9de7861 as layer_6059b49014bdf454a9de7861
import layer_6059b49014bdf454a9de7865 as layer_6059b49014bdf454a9de7865
import layer_6059b49014bdf454a9de7867 as layer_6059b49014bdf454a9de7867
import layer_6059b49014bdf454a9de7869 as layer_6059b49014bdf454a9de7869
import layer_6059b49014bdf454a9de786c as layer_6059b49014bdf454a9de786c
import layer_6059b49014bdf454a9de786e as layer_6059b49014bdf454a9de786e
import layer_6059b49014bdf454a9de7872 as layer_6059b49014bdf454a9de7872
import layer_6059b49014bdf454a9de7874 as layer_6059b49014bdf454a9de7874
import layer_6059b49014bdf454a9de7876 as layer_6059b49014bdf454a9de7876
import layer_6059b49014bdf454a9de7828 as layer_6059b49014bdf454a9de7828
import layer_6059b49014bdf454a9de782a as layer_6059b49014bdf454a9de782a
import layer_6059b49014bdf454a9de782c as layer_6059b49014bdf454a9de782c
import layer_6059b49014bdf454a9de787b as layer_6059b49014bdf454a9de787b
import layer_6059b49014bdf454a9de787d as layer_6059b49014bdf454a9de787d
import layer_6059b49014bdf454a9de7881 as layer_6059b49014bdf454a9de7881
import layer_6059b49014bdf454a9de787f as layer_6059b49014bdf454a9de787f


def get_layer_object(module):
    for member in getmembers(module):
        if member[1].__module__ == module.__name__:
            return member[1]

def get_loss_sum_fn(list_loss):
    def LossSum(y_true, y_pred):
        loss = 0
        for loss_fn in list_loss:
            loss += loss_fn(y_true, y_pred)
        return loss

    return LossSum

class Model(BaseModel):
    def __init__(self, *args, **kwargs):
        super(Model, self).__init__(*args, **kwargs)
        self.path_weight = file_path + "/weight.hdf5"
        inputs, outputs, losses, labels = self.build_source()
        self.compile(inputs, outputs, losses, labels)

    def build_source(self):
        config_loss = dict()
        volume = 256
        height = 256
        width = 256
        channels = 1
        num_class = 6
        output_channels = 1
        batch_size = 1

        n1_Image = layer_6059b49014bdf454a9de7534.Image(shape=[256, 256, 1])
        n2_Backbone_n1_Conv2D = layer_6059b49014bdf454a9de7538.Conv2D(filters=32, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n1_Image)
        n2_Backbone_n3_BatchNormalization = layer_6059b49014bdf454a9de753c.BatchNormalization()(n2_Backbone_n1_Conv2D)
        n2_Backbone_n2_Activation = layer_6059b49014bdf454a9de753a.Activation(activation='relu')(n2_Backbone_n3_BatchNormalization)
        n2_Backbone_n4_Conv2D = layer_6059b49014bdf454a9de753e.Conv2D(filters=32, kernel_size=[3, 3], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n2_Activation)
        n2_Backbone_n5_BatchNormalization = layer_6059b49014bdf454a9de7540.BatchNormalization()(n2_Backbone_n4_Conv2D)
        n2_Backbone_n6_Activation = layer_6059b49014bdf454a9de7542.Activation(activation='relu')(n2_Backbone_n5_BatchNormalization)
        n2_Backbone_n7_Conv2D = layer_6059b49014bdf454a9de7544.Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n6_Activation)
        n2_Backbone_n8_BatchNormalization = layer_6059b49014bdf454a9de7546.BatchNormalization()(n2_Backbone_n7_Conv2D)
        n2_Backbone_n9_Activation = layer_6059b49014bdf454a9de7548.Activation(activation='relu')(n2_Backbone_n8_BatchNormalization)
        n2_Backbone_n10_MaxPooling2D = layer_6059b49014bdf454a9de754a.MaxPooling2D(pool_size=[2, 2], strides=[2, 2], padding='valid')(n2_Backbone_n9_Activation)
        n2_Backbone_n11_mixed_0_n9_Activation = layer_6059b49014bdf454a9de7588.Activation(activation='linear')(n2_Backbone_n10_MaxPooling2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7550.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7554.BatchNormalization()(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7558.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de755c.BatchNormalization()(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7568.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de756c.BatchNormalization()(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n7_AveragePooling2D = layer_6059b49014bdf454a9de757e.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7582.Conv2D(filters=32, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7586.BatchNormalization()(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7552.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de755a.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7560.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7564.BatchNormalization()(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de756a.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7570.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7574.BatchNormalization()(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7584.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7562.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7572.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7578.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de757c.BatchNormalization()(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de757a.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de758d.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_6059b49014bdf454a9de758d.Concatenate(axis=-1)([n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_6059b49014bdf454a9de758d.Concatenate(axis=-1)(*[n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n12_mixed_0_n9_Activation = layer_6059b49014bdf454a9de75cb.Activation(activation='linear')(n2_Backbone_n11_mixed_0_n10_Concatenate)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7593.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7597.BatchNormalization()(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de759b.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de759f.BatchNormalization()(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75ab.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75af.BatchNormalization()(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n7_AveragePooling2D = layer_6059b49014bdf454a9de75c1.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75c5.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75c9.BatchNormalization()(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7595.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de759d.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75a3.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75a7.BatchNormalization()(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75ad.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75b3.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75b7.BatchNormalization()(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75c7.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75a5.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75b5.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75bb.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75bf.BatchNormalization()(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75bd.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de75d0.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_6059b49014bdf454a9de75d0.Concatenate(axis=-1)([n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_6059b49014bdf454a9de75d0.Concatenate(axis=-1)(*[n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n13_mixed_0_n9_Activation = layer_6059b49014bdf454a9de760e.Activation(activation='linear')(n2_Backbone_n12_mixed_0_n10_Concatenate)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75d6.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75da.BatchNormalization()(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75de.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75e2.BatchNormalization()(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75ee.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75f2.BatchNormalization()(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n7_AveragePooling2D = layer_6059b49014bdf454a9de7604.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7608.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de760c.BatchNormalization()(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75d8.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75e0.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75e6.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75ea.BatchNormalization()(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75f0.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75f6.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de75fa.BatchNormalization()(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de760a.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75e8.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de75f8.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de75fe.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7602.BatchNormalization()(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7600.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7613.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_6059b49014bdf454a9de7613.Concatenate(axis=-1)([n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_6059b49014bdf454a9de7613.Concatenate(axis=-1)(*[n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n14_mixed_3_n2_Activation = layer_6059b49014bdf454a9de761f.Activation(activation='linear')(n2_Backbone_n13_mixed_0_n10_Concatenate)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7623.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7625.BatchNormalization()(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7627.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de762b.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de762d.BatchNormalization()(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de762f.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7633.Conv2D(filters=96, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7635.BatchNormalization()(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7637.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n6_MaxPooling2D = layer_6059b49014bdf454a9de7639.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7619.Conv2D(filters=384, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de761b.BatchNormalization()(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de761d.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de763d.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_6059b49014bdf454a9de763d.Concatenate(axis=-1)([n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_6059b49014bdf454a9de763d.Concatenate(axis=-1)(*[n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n15_mixed_0_n7_Activation = layer_6059b49014bdf454a9de7671.Activation(activation='linear')(n2_Backbone_n14_mixed_3_n7_Concatenate)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7643.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7647.BatchNormalization()(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de764b.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de764f.BatchNormalization()(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7661.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7665.BatchNormalization()(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n5_AveragePooling2D = layer_6059b49014bdf454a9de7667.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de766b.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de766f.BatchNormalization()(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7645.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de764d.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7653.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7657.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7663.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de766d.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de767a.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de767e.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7655.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de7659.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de765b.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de765d.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de767c.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de7680.Conv2D(filters=128, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de7682.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de7684.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7688.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de768c.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de768a.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de768e.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de7690.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de7692.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7676.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de7676.Concatenate(axis=-1)([n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de7676.Concatenate(axis=-1)(*[n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n16_mixed_0_n7_Activation = layer_6059b49014bdf454a9de76c6.Activation(activation='linear')(n2_Backbone_n15_mixed_0_n8_Concatenate)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7698.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de769c.BatchNormalization()(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76a0.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76a4.BatchNormalization()(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76b6.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76ba.BatchNormalization()(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n5_AveragePooling2D = layer_6059b49014bdf454a9de76bc.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76c0.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76c4.BatchNormalization()(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de769a.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76a2.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76a8.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76ac.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76b8.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76c2.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76cf.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76d3.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76aa.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de76ae.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de76b0.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de76b2.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76d1.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de76d5.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de76d7.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de76d9.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76dd.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76e1.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76df.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de76e3.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de76e5.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de76e7.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de76cb.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de76cb.Concatenate(axis=-1)([n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de76cb.Concatenate(axis=-1)(*[n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n18_mixed_0_n7_Activation = layer_6059b49014bdf454a9de7770.Activation(activation='linear')(n2_Backbone_n16_mixed_0_n8_Concatenate)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7742.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7746.BatchNormalization()(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de774a.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de774e.BatchNormalization()(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7760.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7764.BatchNormalization()(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n5_AveragePooling2D = layer_6059b49014bdf454a9de7766.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de776a.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de776e.BatchNormalization()(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7744.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de774c.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7752.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7756.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7762.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de776c.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7779.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de777d.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7754.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de7758.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de775a.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de775c.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de777b.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de777f.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de7781.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de7783.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7787.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de778b.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7789.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de778d.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de778f.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de7791.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7775.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de7775.Concatenate(axis=-1)([n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de7775.Concatenate(axis=-1)(*[n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n17_mixed_0_n7_Activation = layer_6059b49014bdf454a9de771b.Activation(activation='linear')(n2_Backbone_n18_mixed_0_n8_Concatenate)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76ed.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76f1.BatchNormalization()(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76f5.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de76f9.BatchNormalization()(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de770b.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de770f.BatchNormalization()(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n5_AveragePooling2D = layer_6059b49014bdf454a9de7711.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7715.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7719.BatchNormalization()(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76ef.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76f7.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de76fd.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7701.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de770d.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7717.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7724.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7728.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de76ff.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de7703.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de7705.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de7707.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7726.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de772a.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de772c.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de772e.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7732.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_6059b49014bdf454a9de7736.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation = layer_6059b49014bdf454a9de7734.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de7738.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de773a.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de773c.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7720.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de7720.Concatenate(axis=-1)([n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_6059b49014bdf454a9de7720.Concatenate(axis=-1)(*[n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n19_mixed_3_n2_Activation = layer_6059b49014bdf454a9de779d.Activation(activation='linear')(n2_Backbone_n17_mixed_0_n8_Concatenate)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77a1.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77a3.BatchNormalization()(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77a5.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77a9.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77ab.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77ad.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D = layer_6059b49014bdf454a9de77af.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization = layer_6059b49014bdf454a9de77b1.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation = layer_6059b49014bdf454a9de77b3.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77b7.Conv2D(filters=192, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77b9.BatchNormalization()(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77bb.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n6_MaxPooling2D = layer_6059b49014bdf454a9de77bd.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7797.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7799.BatchNormalization()(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de779b.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77c5.Conv2D(filters=320, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77c7.BatchNormalization()(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77c9.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de77c1.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_6059b49014bdf454a9de77c1.Concatenate(axis=-1)([n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_6059b49014bdf454a9de77c1.Concatenate(axis=-1)(*[n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n2_Activation = layer_6059b49014bdf454a9de77d5.Activation(activation='linear')(n2_Backbone_n19_mixed_3_n7_Concatenate)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77d9.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77db.BatchNormalization()(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77dd.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77e1.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77e3.BatchNormalization()(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77e5.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77e9.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77eb.BatchNormalization()(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77ed.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de77f0.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_6059b49014bdf454a9de77f0.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_6059b49014bdf454a9de77f0.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77f4.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77f6.BatchNormalization()(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77f8.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77fc.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77fe.BatchNormalization()(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7800.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7804.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7806.BatchNormalization()(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7808.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de780c.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de780e.BatchNormalization()(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7810.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7813.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_6059b49014bdf454a9de7813.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_6059b49014bdf454a9de7813.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n12_AveragePooling2D = layer_6059b49014bdf454a9de7815.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7819.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de781b.BatchNormalization()(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de781d.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de77cf.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de77d1.BatchNormalization()(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de77d3.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7822.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_6059b49014bdf454a9de7822.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_6059b49014bdf454a9de7822.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n2_Activation = layer_6059b49014bdf454a9de782e.Activation(activation='linear')(n2_Backbone_n20_mixed_9_n14_Concatenate)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7832.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7834.BatchNormalization()(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7836.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de783a.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de783c.BatchNormalization()(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de783e.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7842.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7844.BatchNormalization()(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7846.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de7849.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_6059b49014bdf454a9de7849.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_6059b49014bdf454a9de7849.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de784d.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de784f.BatchNormalization()(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7851.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7855.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7857.BatchNormalization()(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7859.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de785d.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de785f.BatchNormalization()(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7861.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7865.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7867.BatchNormalization()(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7869.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de786c.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_6059b49014bdf454a9de786c.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_6059b49014bdf454a9de786c.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n12_AveragePooling2D = layer_6059b49014bdf454a9de786e.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7872.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de7874.BatchNormalization()(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de7876.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_6059b49014bdf454a9de7828.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_6059b49014bdf454a9de782a.BatchNormalization()(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation = layer_6059b49014bdf454a9de782c.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b49014bdf454a9de787b.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_6059b49014bdf454a9de787b.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_6059b49014bdf454a9de787b.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        n3_GlobalAveragePooling2D = layer_6059b49014bdf454a9de787d.GlobalAveragePooling2D()(n2_Backbone_n21_mixed_9_n14_Concatenate)
        n9_Dropout = layer_6059b49014bdf454a9de7881.Dropout(rate=0.5)(n3_GlobalAveragePooling2D)
        n4_Dense = layer_6059b49014bdf454a9de787f.Dense(units=6, activation='softmax', use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n9_Dropout)
        label = keras.layers.Input(shape=[6])
        loss = keras.losses.CategoricalCrossentropy()(label, n4_Dense)
        



        for key in list(config_loss.keys()):
            if len(config_loss[key]) == 1:
                config_loss[key] = config_loss[key][0]
            elif len(config_loss[key]) > 1:
                config_loss[key] = get_loss_sum_fn(config_loss[key])
            else:
                del config_loss[key]
        inputs = [n1_Image]
        outputs = [n4_Dense]
        losses = [loss]
        labels = [label]

        return inputs, outputs, losses, labels

