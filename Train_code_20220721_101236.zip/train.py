
import sys
sys.path.append("./library/")


import copy

from deepphi.io.sitk import DeepPhiDataSet
import Color_to_Grayscale_54447.source_code
import Resize_54449.source_code
import Histogram_Equalization_CLAHE___Grayscale_54451.source_code
import Min_Max_Normalization_54448.source_code
import Xception_55285.source_code
import DensNet121_55286.source_code
import InceptionV3_55282.source_code
import VGG19_54457.source_code
import Feature_Merge_55645.source_code


def inference(path_image):
    input_image = DeepPhiDataSet()
    input_image.read_image(path_image)

    output_Color_to_Grayscale_54447 = Color_to_Grayscale_54447.source_code.ColortoGrayscale()(input_image)
    output_Resize_54449 = Resize_54449.source_code.Resize(volume=1, width=256, height=256)(output_Color_to_Grayscale_54447)
    output_Histogram_Equalization_CLAHE___Grayscale_54451 = Histogram_Equalization_CLAHE___Grayscale_54451.source_code.HistogramEqualization__CLAHE_gray(limit=2, kernel_size=7)(output_Resize_54449)
    output_Min_Max_Normalization_54448 = Min_Max_Normalization_54448.source_code.Min_Max_Normalization()(output_Histogram_Equalization_CLAHE___Grayscale_54451)
    output_Xception_55285 = Xception_55285.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_54448)
    output_DensNet121_55286 = DensNet121_55286.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_54448)
    output_InceptionV3_55282 = InceptionV3_55282.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_54448)
    output_VGG19_54457 = VGG19_54457.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_54448)
    output_Feature_Merge_55645 = Feature_Merge_55645.source_code.FeatureMerge()(output_VGG19_54457, output_InceptionV3_55282, output_Xception_55285, output_DensNet121_55286)

    return output_Feature_Merge_55645


if __name__ == "__main__":
    path_image = ""
    result = inference(path_image)
