#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing


class CustomImageProcessing(Preprocessing):

    def __init__(self, *args, **kwargs):
        """Initialization of Image Processing Class Module.

        if kwargs exists, please double check whether the desired parameter is
        entered or not.

        Example:

        if isinstance(kwargs['keyword_argument'], DesiredType):
            self.kwargs=kwargs
            self.keyword_argument=kwargs['keyword_argument']

        Sample self Args:

            self.data           (hdf5)  input hdf5 data to be processed.
            self.args           (tbd)   input argument for image processing
                                        upon class instantiation.
            self.kwargs         (tbd)   keyword argument for image processing
                                        upon class instantiation.
            self.color_mode     (str)   Color mode of the output image array
        """

        super(CustomImageProcessing, self).__init__()
        """ Image Processing Parameters """
        self.data = None
        self.args = args
        self.kwargs = kwargs
        self.color_mode = ''  # TODO: FILL

    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        self.image_processing(self.get_image_array(),
                              param=[self.args,
                                     self.kwargs])

        # Return_Output_HDF5
        return self.data

    def io_error_check(self):
        """ Check the input data before processing the module.

        Here, you can check data type, modality type, image shape,
        and/or color modes etc.

        Example:

        ACCEPTABLE_COLORS = ['RGB']
        color_mode = self.get_color_mode()

        if color_mode not in ACCEPTABLE_COLORS:
            raise Exception('Input Image color-mode Must Match.\nAccepts--'
                            + str(ACCEPTABLE_COLORS))

        MODALITIES = ['MRI']
        modality = self.get_modality()

        if modality in MODALITIES:
            raise Exception('Input Modality Type Must Match.\nAccepts--'
                            + str(MODALITIES))

        """

        pass
    
    def image_processing(self, source_image, param):
        """Perform image processing onto the source image.

        Args:
            source_image    (ndarray)   input image array to be processed.
            param           (tbd)       image processing argument.(if, any)
        """
        try:
            # Custom_Image_Processing
            output_img = self.custom_image_processing(source_image, param)
            
            color_processed = False
            # Update_Info
            self.add_array(output_img)
            if color_processed:
                self.add_color_mode(self.color_mode)
            return output_img

        except Exception as error:
            raise Exception("Exception occurred while processing:" + str(error))

    def custom_image_processing(self, source_image, param):
        """ Custom image processing method.

        Args:
            source_image    (ndarray)   input image array to be processed
            param           (tbd)       image processing argument.(if, any)

        Returns:
            output_image    (ndarray)   output image array after processed.


        Example:
            output_image = cv2.cvtColor(source_image, cv2.COLOR_RGB2GRAY)
        """
        """ 
        ##################################################
    
                    Do Image Processing Here

        ##################################################
        """
        raise NotImplementedError
