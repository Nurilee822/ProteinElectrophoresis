#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.color_mode_ import *
from deepphi.image_processing.utils import timeit


class ColorMode(Preprocessing):
    """Returns color-mode-converted hdf5 image.

    Available modes:
    RGB mode (Red, Green, Blue)
    HSV mode (Hue, Saturation, Value)
    L mode (Grayscale, 256 levels)
    B mode (Binary, black or white)

    """

    def __init__(self, *args, **kwargs):
        """Initialization of ColorMode Class Module.

        self Variables:
            self.log           (logger) logger for logging.
            self.args           (tbd)   input argument for image processing.
            self.kwargs         (tbd)   keyword argument for image processing.
            self.this_mode         (str)    new color mode.
            self.acceptable_colors (list)   list of acceptable colors.
        """
        super(ColorMode, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.this_mode = None
        self.acceptable_colors = None
        self.this_module = None
        self.error_msg = None

    @timeit
    def __call__(self, source_data, save_path=None):

        # IO_Error_Check
        self.init_data(source_data)
        self.io_error_check()

        # Image_Processing
        source_img = self.get_image_array()
        source_color_mode = (self.get_color_mode()).upper()
        self.image_processing(source_image=source_img,
                              param=[self.args,
                                     self.kwargs])
        output_color_mode = self.get_color_mode()

        # Logging_Info
        self.log.debug('module processed: \t\t\t{}'.format(self.this_module))
        self.log.debug('original_color_mode: \t\t{}'.format(source_color_mode))
        self.log.debug('converted_color_mode: \t\t{}'.format(output_color_mode))
        self.log.debug('IsVector: \t\t\t\t\t{}'.format(self._data['image']['header']['IsVector']))
        self.add_logging()
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """

        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Converts to color mode of desire onto an image.
        Returns a numpy array.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Convert_Color_Mode
            if self.get_color_mode().upper() == self.this_mode:
                output_img = source_image
            else:
                output_img = self.convert_color_mode(source_image)

            # Update_Info
            self.add_shapes(source_image, output_img)
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(self.this_mode)
            self.update_isvector()

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(self.error_msg)

    def convert_color_mode(self, source_image):
        raise ModuleNotFoundError

    def add_logging(self):
        pass

    def add_shapes(self, source_image, output_image):
        pass

    def update_isvector(self):
        if len(self.this_mode) == 1:
            self._data['image']['header']['IsVector'] = False
        else:
            self._data['image']['header']['IsVector'] = True
