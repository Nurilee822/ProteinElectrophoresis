#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing.converter.color_mode import ColorMode
import numpy as np
import logging

B = 'B'
BINARY = 'BINARY'
INV_BINARY = 'INV_B'
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data, Input array must be a binary, black and white image."


class InvertBinary(ColorMode):
    def __init__(self, *args, **kwargs):
        super(InvertBinary, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.acceptable_colors = [B, BINARY, INV_BINARY]
        self.this_mode = INV_BINARY
        self.this_module = __class__.__name__
        self.error_msg = COLOR_MODE_ERROR_MSG

    def convert_color_mode(self, source_image):
        return np.invert(source_image)


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, LOCAL_DATA
    from deepphi.image_processing.converter.color_mode.hsv_to_binary import HSVtoBINARY
    L = 'gray'
    IMAGE = 'image'
    ARRAY = 'array'
    DATA = LOCAL_DATA

    hdf5_input = test_prep(DATA, level='HSV', log=True)
    input_img = hdf5_input[IMAGE][ARRAY]

    hsv2bin = HSVtoBINARY()
    hdf5_bin = hsv2bin(hdf5_input)
    bin_img = hdf5_bin[IMAGE][ARRAY]

    inv_bin = InvertBinary()
    hdf5_inv = inv_bin(hdf5_bin)
    inv_img = hdf5_inv[IMAGE][ARRAY]

    display(input_img, add_to_title='Input Image', cmap=L)
    display(bin_img, add_to_title='Binary Image', cmap=L)
    display(inv_img, add_to_title='Inverted Image', cmap=L)
