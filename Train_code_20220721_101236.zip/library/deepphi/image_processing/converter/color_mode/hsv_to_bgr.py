#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
from deepphi.image_processing.converter.color_mode import ColorMode
from deepphi.image_processing.utils import display

HSV = 'HSV'
BGR = 'BGR'

COLOR_MODE_ERROR_MSG = "Exception occurred while reading data, Input array must be a 3-channel, HSV color image."
"""
EXAMPLE:

    hsv2bgr = HSVtoBGR()

    hdf5_output = hsv2bgr(hdf5_input)

"""


class HSVtoBGR(ColorMode):
    """Returns a BGR image. Converts HSV type image to the BGR image type.

        Convert color mode from
        HSV(Hue, Saturation, and Value) to
        BGR(Red, Green, and Blue).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of HSVtoBGR Class Module.

        self Variables:
            self.this_module        (str)     name of the current module.
            self.acceptable_colors  (list)    list of acceptable colors.
            self.this_mode          (str)     color mode setting for the module.
        """
        super(HSVtoBGR, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.acceptable_colors = [HSV, BGR]
        self.this_mode = BGR
        self.this_module = __class__.__name__
        self.error_msg = COLOR_MODE_ERROR_MSG

    def convert_color_mode(self, source_image):
        return cv2.cvtColor(source_image, cv2.COLOR_HSV2BGR)


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, LOCAL_DATA

    # prepare hsv hdf5 image
    hdf5_input = test_prep(LOCAL_DATA, level='HSV', log=True)
    hsv_image = hdf5_input['image']['array']

    # run input hdf5
    hsv2bgr = HSVtoBGR()
    hdf5_output = hsv2bgr(hdf5_input)
    bgr_image = hdf5_output['image']['array']

    # display
    display(hsv_image, add_to_title='HSV Image')
    display(bgr_image, add_to_title='BGR Image')


