#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
from deepphi.image_processing.converter.color_mode import ColorMode
from deepphi.image_processing.utils import display

COLOR_MODE_ERROR_MSG = "Exception occurred while reading data: Input array must be a 4-channel, RGBA color image."
RGBA = 'RGBA'
RGB = 'RGB'

"""
EXAMPLE:

    rgba2rgb = RGBAtoRGB()

    hdf5_output = rgba2rgb(hdf5_input)

"""


class RGBAtoRGB(ColorMode):
    """Returns an RGB image. Converts RGBA type image to RGB image type.

        Convert color mode from
        RGBA(Red, Green, Blue, and Alpha) to
        RGB(Red, Green, and Blue).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of RGBAtoRGB Class Module.

        self Variables:
            self.module_name        (logger)  name of the current module.
            self.acceptable_colors  (tbd)     list of acceptable colors.
            self.this_mode          (tbd)     color mode setting for the module.
        """
        super(RGBAtoRGB, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.acceptable_colors = [RGBA, RGB]
        self.this_mode = RGB
        self.this_module = __class__.__name__
        self.input_shape = None
        self.output_shape = None

    def convert_color_mode(self, source_image):
        output_image = cv2.cvtColor(source_image, cv2.COLOR_RGBA2RGB)

        return output_image

    def add_shapes(self, source_image, output_image):
        self.input_shape = np.shape(source_image)[-1]
        self.output_shape = np.shape(output_image)[-1]


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, LOCAL_DATA
    from PIL import Image
    import numpy as np

    # prepare rgba hdf5 image
    hdf5_input = test_prep(LOCAL_DATA, log=True)

    input_image = hdf5_input['image']['array']

    # RGBA_PATH = '/home/hslisalee/DEEPPHI/io/hdf5/svs/1035154_lv2_rgba.png'
    # input_image = np.array(Image.open(RGBA_PATH))
    #
    # hdf5_input['image']['array'] = input_image
    # hdf5_input['image']['header']['color_mode'] = 'RGBA'

    # run input hdf5
    rgba2rgb = RGBAtoRGB()
    hdf5_output = rgba2rgb(hdf5_input)
    rgb_image = hdf5_output['image']['array']

    # display
    display(input_image, add_to_title='RGBA Image')
    display(rgb_image, add_to_title='RGB Image')


