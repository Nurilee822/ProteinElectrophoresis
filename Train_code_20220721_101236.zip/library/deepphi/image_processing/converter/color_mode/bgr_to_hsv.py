#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
from deepphi.image_processing.converter.color_mode import ColorMode

BGR = 'BGR'
HSV = 'HSV'
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data, Input array must be a 3-channel, BGR color image."


class BGRtoHSV(ColorMode):
    """Returns an HSV image. Converts BGR type image to HSV image type.

        Convert color mode from
        BGR(Blue, Green and Red) to
        HSV(Hue, Saturation, and Value).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of BGRtoHSV Class Module.

        self Variables:
            self.module_name        (logger)  name of the current module.
            self.acceptable_colors  (tbd)     list of acceptable colors.
            self.this_mode          (tbd)     color mode setting for the module.
        """
        super(BGRtoHSV, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.acceptable_colors = [BGR, HSV]
        self.this_mode = HSV
        self.this_module = __class__.__name__
        self.error_msg = COLOR_MODE_ERROR_MSG

    def convert_color_mode(self, source_image):
        return cv2.cvtColor(source_image, cv2.COLOR_BGR2HSV)


if __name__ == "__main__":
    from deepphi.image_processing.utils import LOCAL_DATA, test_prep, display
    from deepphi.image_processing.converter.color_mode.rgb_to_bgr import \
        RGBtoBGR

    # prepare bgr hdf5 image
    hdf5_input = test_prep(LOCAL_DATA, log=True)
    rgb2bgr = RGBtoBGR()
    hdf5_bgr = rgb2bgr(hdf5_input)
    bgr_image = hdf5_input['image']['array']

    # run input hdf5
    bgr2hsv = BGRtoHSV()
    hdf5_output = bgr2hsv(hdf5_input)
    hsv_image = hdf5_output['image']['array']

    # display
    display(bgr_image, add_to_title='BGR Image')
    display(hsv_image, add_to_title='HSV Image')


