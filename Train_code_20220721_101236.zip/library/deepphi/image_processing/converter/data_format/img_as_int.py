#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import sys

from deepphi.image_processing.converter.data_format import DataFormat
from deepphi.io.sitk import DeepPhiDataSet

INT_ = 'int16'


class ImgAsInt(DataFormat):
    """Returns an hdf5 image in which image array is of int16."""

    def __init__(self, *args, **kwargs):
        """Initialization of ImgAsInt Class Module.

        self Variables:
            self.dtype  (str)   input data type
        """
        super(ImgAsInt, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.dtype = INT_
        self.this_module = __class__.__name__


if __name__ == "__main__":
    from deepphi.image_processing.utils import LOCAL_DATA

    # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import environment settings
    hdf5_input = DeepPhiDataSet()

    # import hdf5 image
    hdf5_input.load(LOCAL_DATA)
    source_img = hdf5_input['image']['array']

    # run input hdf5
    data_format = ImgAsInt()
    hdf5_output = data_format(hdf5_input)
    output_img = hdf5_output['image']['array']

