#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.data_format_ import *
from deepphi.image_processing.utils import timeit


class DataFormat(Preprocessing):
    """Returns image-array-type-converted hdf5 image."""

    def __init__(self, *args, **kwargs):
        """Initialization of DataFormat Class Module.

        self Variables:
            self.log           (logger) logger for logging.
            self.args           (tbd)   input argument for image processing.
            self.kwargs         (tbd)   keyword argument for image processing.
        """
        super(DataFormat, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.dtype = None
        self.this_module = __class__.__name__

    @timeit
    def __call__(self, source_data, save_path=None):

        # IO_Error_Check
        self.init_data(source_data)
        self.io_error_check()

        # Image_Processing
        source_img = self.get_image_array()
        source_img_type = self.get_dtype()
        self.image_processing(source_img=source_img,
                              param=[self.args,
                                     self.kwargs])
        output_img_type = self.get_dtype()

        # Logging_Info
        self.log.debug('module processed: \t\t\t{}'.format(self.this_module))
        self.log.debug('original image dtype: \t\t{}'.format(source_img_type))
        self.log.debug('converted image dtype: \t\t{}'.format(output_img_type))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        """

        self.empty_check()

        if not isinstance(self.get_image_array(), NP_NDARRAY):
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_img, param):
        """Converts the source image array to the data type of desire.

        Returns a numpy array.

        Args:
            source_img (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:

            # Convert_Dtype & Update_Info
            self.add_array(self.get_image_array(), self.dtype)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)
