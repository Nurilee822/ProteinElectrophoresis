#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import matplotlib.pyplot as plt
from deepphi.image_processing import Preprocessing
from deepphi.io.sitk import *
import logging


class TemporaryDataset(DeepPhiDataSet):
    def save(self, filename):
        filename_jpg = ''
        list_piece = filename.split('.')
        for piece in list_piece[:-1]:
            filename_jpg = filename_jpg + piece
        filename_jpg = filename_jpg + '.jpg'
        plt.imsave(filename_jpg, self['image']['array'])


class Hdf52JPG(Preprocessing):
    def __init__(self):
        super(Hdf52JPG, self).__init__(self)
        self.log = logging.getLogger()

    def __call__(self, data, save_path=None):
        deepphi_dataset = TemporaryDataset()
        deepphi_dataset['image']['array'] = data['image']['array']
        if save_path is not None:
            self.save(save_path, data)
        return deepphi_dataset
