import traceback
import logging


class DeepPhiError(Exception):
    def __init__(self, code=None, msg=None, parameter=None):
        super(DeepPhiError, self).__init__(code)
        self.code = code
        self.msg = msg
        self.parameter = self.convert_param_to_str(parameter)

    def convert_param_to_str(self, parameter):
        if not isinstance(parameter, dict):
            return dict()

        for key in parameter.keys():
            if not isinstance(parameter[key], str):
                parameter[key] = str(parameter[key])
        return parameter

    def get_message(self):
        if self.code is None:
            return self.msg
        else:
            return self.code

    def get_parameter(self):
        if self.parameter is None:
            return dict()
        else:
            return self.parameter


class ErrorAnalyzer(object):
    def __init__(self, exception):
        self.exception = exception
        self.error_type = self.get_error_type()

        self.info = {
            "message": "",
            "detail": "",
            "messageParameter": dict()
        }

    def get_error_type(self):
        return self.exception.__class__.__name__

    def get_error_msg(self):
        self.info['detail'] = str(traceback.format_exc())

        if self.error_type == 'DeepPhiError':
            self.info['message'] = self.exception.get_message()
            self.info['messageParameter'] = self.exception.get_parameter()
        else:
            self.info['message'] = str(self.exception)
        return self.info


if __name__ == "__main__":
    try:
        raise DeepPhiError(msg="412341234", code='this is code', parameter={'param1': 123, 'param2': 456})
    except Exception as exception:
        test = ErrorAnalyzer(exception, 123)
        print(test.get_error_msg())
