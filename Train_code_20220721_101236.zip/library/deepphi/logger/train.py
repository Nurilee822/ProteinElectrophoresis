#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import datetime
import json
import parse
import logging
import math
from deepphi.logger.error import *

def train_history_logger(filename, history, epoch=None, time=None, num_step=None, type=None, class_name=None):
    history_to_json = dict()

    history_to_json['epoch'] = int(epoch)
    history_to_json['epoch_finish_time'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    history_to_json['time'] = time
    history_to_json['processing_time'] = time / num_step
    history_to_json['class'] = list()

    type = type.lower()

    for key in history.keys():
        key_new = key.replace("categorical_", "")
        key_new = key_new.replace("n34_Concatenate_", "")
        key_new = key_new.replace("n33_Concatenate_", "")
        if math.isnan(float(history[key][0])) or math.isinf(float(history[key][0])):
            msg = '"NaN" or "inf" occur in the result of loss or metric operation. There are two possibilities.'
            msg = msg + '\n\n1. Loss divergence occurrs due to too high a learning rate. Modify the learning rate to be smaller.'
            msg = msg + '\n\n2. Numerical Exception occurs in the loss function. Modify the loss to avoid throwing an exception. (ex. when dividing by 0)'
            raise DeepPhiError(code="worker.neural-network.error.metric-result-not-a-number")
        else:
            history_to_json[key_new] = float(history[key][0])

    # if type == "detection":
    #     logging.info(history)

    metric_class = dict()
    for key in list(history_to_json.keys()):
        if 'ClassWise' not in key:
            continue

        metric_name, class_id = parse.parse('{}ClassWise_id_{}', key)
        if class_id not in metric_class.keys():
            metric_class[class_id] = dict()
            metric_class[class_id]['classId'] = class_id
            metric_class[class_id]['className'] = class_name[int(class_id)]
        if (metric_name == "Accuracy") and (type == 'detection'):
            metric_class[class_id]['average_precision'] = history_to_json[key]
        elif (metric_name == "val_Accuracy") and (type == 'detection'):
            metric_class[class_id]['val_average_precision'] = history_to_json[key]
        else:
            metric_class[class_id][metric_name.lower()] = history_to_json[key]
        del history_to_json[key]

    tp = 0
    tn = 0
    fp = 0
    fn = 0

    vtp = 0
    vtn = 0
    vfp = 0
    vfn = 0

    for cls in metric_class.keys():
        if (('val_truepositive' in metric_class[cls].keys()) and
                ('val_truenegative' in metric_class[cls].keys()) and
                ('val_falsepositive' in metric_class[cls].keys()) and
                ('val_falsenegative' in metric_class[cls].keys())):
            exist_validation = True
        else:
            exist_validation = False

        if type == "detection":
            metric_new = metric_class[cls]
        else:
            tp += metric_class[cls]['truepositive']
            tn += metric_class[cls]['truenegative']
            fp += metric_class[cls]['falsepositive']
            fn += metric_class[cls]['falsenegative']

            if exist_validation:
                vtp += metric_class[cls]['val_truepositive']
                vtn += metric_class[cls]['val_truenegative']
                vfp += metric_class[cls]['val_falsepositive']
                vfn += metric_class[cls]['val_falsenegative']

            metric_new = cal_metrics(metric_class[cls], type, exist_validation=exist_validation)

        history_to_json['class'].append(metric_new)

    if type in ["transformation", "timeSeries"]:
        del history_to_json['class']
    elif type in ["classification", "segmentation"]:
        history_to_json['accuracy'] = (tp + tn) / (tp + tn + fp + fn)
        if exist_validation:
            history_to_json['val_accuracy'] = (vtp + vtn) / (vtp + vtn + vfp + vfn)

    return history_to_json


Epsilon = 1e-6


def cal_metrics(metric_class, type, exist_validation=True):
    tp = metric_class['truepositive']
    tn = metric_class['truenegative']
    fp = metric_class['falsepositive']
    fn = metric_class['falsenegative']

    accuracy = cal_accuracy(tp, tn, fp, fn)
    dice = cal_dice_coefficient(tp, tn, fp, fn)
    sensitivity = cal_sensitivity(tp, tn, fp, fn)
    specificity = cal_specificity(tp, tn, fp, fn)
    ppv = cal_ppv(tp, tn, fp, fn)
    npv = cal_npv(tp, tn, fp, fn)

    del metric_class['truepositive']
    del metric_class['truenegative']
    del metric_class['falsepositive']
    del metric_class['falsenegative']

    metric_class['accuracy'] = accuracy
    metric_class['sensitivity'] = sensitivity
    metric_class['specificity'] = specificity
    metric_class['ppv'] = ppv
    metric_class['npv'] = npv

    if type == 'segmentation':
        metric_class['dice'] = dice
    else:
        metric_class['f1_score'] = dice

    if exist_validation:

        val_tp = metric_class['val_truepositive']
        val_tn = metric_class['val_truenegative']
        val_fp = metric_class['val_falsepositive']
        val_fn = metric_class['val_falsenegative']

        val_accuracy = cal_accuracy(val_tp, val_tn, val_fp, val_fn)
        val_dice = cal_dice_coefficient(val_tp, val_tn, val_fp, val_fn)
        val_sensitivity = cal_sensitivity(val_tp, val_tn, val_fp, val_fn)
        val_specificity = cal_specificity(val_tp, val_tn, val_fp, val_fn)
        val_ppv = cal_ppv(val_tp, val_tn, val_fp, val_fn)
        val_npv = cal_npv(val_tp, val_tn, val_fp, val_fn)

        del metric_class['val_truepositive']
        del metric_class['val_truenegative']
        del metric_class['val_falsepositive']
        del metric_class['val_falsenegative']

        metric_class['val_accuracy'] = val_accuracy

        metric_class['val_sensitivity'] = val_sensitivity
        metric_class['val_specificity'] = val_specificity
        metric_class['val_ppv'] = val_ppv
        metric_class['val_npv'] = val_npv

        if type == 'segmentation':
            metric_class['val_dice'] = val_dice
        else:
            metric_class['val_f1_score'] = val_dice

    return metric_class


def cal_accuracy(tp, tn, fp, fn):
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    return accuracy


def cal_sensitivity(tp, tn, fp, fn):
    sensitivity = tp / (tp + fn + Epsilon)
    return sensitivity


def cal_specificity(tp, tn, fp, fn):
    specificity = tn / (tn + fp + Epsilon)
    return specificity


def cal_ppv(tp, tn, fp, fn):
    ppv = tp / (tp + fp + Epsilon)
    return ppv


def cal_npv(tp, tn, fp, fn):
    npv = tn / (tn + fn + Epsilon)
    return npv


# def cal_precision(tp, tn, fp, fn):
#     precision = tp / (tp + fp + Epsilon)
#     return precision


def cal_dice_coefficient(tp, tn, fp, fn):
    dice = 2 * tp / (2 * tp + fp + fn + Epsilon)
    return dice
