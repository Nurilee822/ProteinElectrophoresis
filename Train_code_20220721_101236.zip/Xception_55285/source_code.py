import sys
from tensorflow import keras
import tensorflow.keras.backend as K
import inspect
import os

file_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(f"{file_path}/layers")
sys.path.append(f"{file_path}/utils")


from base_model import BaseModel
from inspect import getmembers, isfunction

import tensorflow as tf
import layer_6059b59314bdf454a9de7950 as layer_6059b59314bdf454a9de7950
import layer_6059b59314bdf454a9de7956 as layer_6059b59314bdf454a9de7956
import layer_6059b59314bdf454a9de7958 as layer_6059b59314bdf454a9de7958
import layer_6059b59314bdf454a9de795a as layer_6059b59314bdf454a9de795a
import layer_6059b59314bdf454a9de795c as layer_6059b59314bdf454a9de795c
import layer_6059b59314bdf454a9de795e as layer_6059b59314bdf454a9de795e
import layer_6059b59314bdf454a9de7960 as layer_6059b59314bdf454a9de7960
import layer_6059b59314bdf454a9de7962 as layer_6059b59314bdf454a9de7962
import layer_6059b59314bdf454a9de7964 as layer_6059b59314bdf454a9de7964
import layer_6059b59314bdf454a9de7968 as layer_6059b59314bdf454a9de7968
import layer_6059b59314bdf454a9de796a as layer_6059b59314bdf454a9de796a
import layer_6059b59314bdf454a9de796c as layer_6059b59314bdf454a9de796c
import layer_6059b59314bdf454a9de796e as layer_6059b59314bdf454a9de796e
import layer_6059b59314bdf454a9de7970 as layer_6059b59314bdf454a9de7970
import layer_6059b59314bdf454a9de7972 as layer_6059b59314bdf454a9de7972
import layer_6059b59314bdf454a9de7975 as layer_6059b59314bdf454a9de7975
import layer_6059b59314bdf454a9de7977 as layer_6059b59314bdf454a9de7977
import layer_6059b59314bdf454a9de7979 as layer_6059b59314bdf454a9de7979
import layer_6059b59314bdf454a9de797b as layer_6059b59314bdf454a9de797b
import layer_6059b59314bdf454a9de797f as layer_6059b59314bdf454a9de797f
import layer_6059b59314bdf454a9de7981 as layer_6059b59314bdf454a9de7981
import layer_6059b59314bdf454a9de7983 as layer_6059b59314bdf454a9de7983
import layer_6059b59314bdf454a9de7985 as layer_6059b59314bdf454a9de7985
import layer_6059b59314bdf454a9de7987 as layer_6059b59314bdf454a9de7987
import layer_6059b59314bdf454a9de7989 as layer_6059b59314bdf454a9de7989
import layer_6059b59314bdf454a9de798c as layer_6059b59314bdf454a9de798c
import layer_6059b59314bdf454a9de798e as layer_6059b59314bdf454a9de798e
import layer_6059b59314bdf454a9de7990 as layer_6059b59314bdf454a9de7990
import layer_6059b59314bdf454a9de7992 as layer_6059b59314bdf454a9de7992
import layer_6059b59314bdf454a9de7996 as layer_6059b59314bdf454a9de7996
import layer_6059b59314bdf454a9de7998 as layer_6059b59314bdf454a9de7998
import layer_6059b59314bdf454a9de799a as layer_6059b59314bdf454a9de799a
import layer_6059b59314bdf454a9de799c as layer_6059b59314bdf454a9de799c
import layer_6059b59314bdf454a9de799e as layer_6059b59314bdf454a9de799e
import layer_6059b59314bdf454a9de79a0 as layer_6059b59314bdf454a9de79a0
import layer_6059b59314bdf454a9de79a3 as layer_6059b59314bdf454a9de79a3
import layer_6059b59314bdf454a9de79b7 as layer_6059b59314bdf454a9de79b7
import layer_6059b59314bdf454a9de79a7 as layer_6059b59314bdf454a9de79a7
import layer_6059b59314bdf454a9de79a9 as layer_6059b59314bdf454a9de79a9
import layer_6059b59314bdf454a9de79ab as layer_6059b59314bdf454a9de79ab
import layer_6059b59314bdf454a9de79ad as layer_6059b59314bdf454a9de79ad
import layer_6059b59314bdf454a9de79af as layer_6059b59314bdf454a9de79af
import layer_6059b59314bdf454a9de79b1 as layer_6059b59314bdf454a9de79b1
import layer_6059b59314bdf454a9de79b3 as layer_6059b59314bdf454a9de79b3
import layer_6059b59314bdf454a9de79b5 as layer_6059b59314bdf454a9de79b5
import layer_6059b59314bdf454a9de79ba as layer_6059b59314bdf454a9de79ba
import layer_6059b59314bdf454a9de79ce as layer_6059b59314bdf454a9de79ce
import layer_6059b59314bdf454a9de79be as layer_6059b59314bdf454a9de79be
import layer_6059b59314bdf454a9de79c0 as layer_6059b59314bdf454a9de79c0
import layer_6059b59314bdf454a9de79c2 as layer_6059b59314bdf454a9de79c2
import layer_6059b59314bdf454a9de79c4 as layer_6059b59314bdf454a9de79c4
import layer_6059b59314bdf454a9de79c6 as layer_6059b59314bdf454a9de79c6
import layer_6059b59314bdf454a9de79c8 as layer_6059b59314bdf454a9de79c8
import layer_6059b59314bdf454a9de79ca as layer_6059b59314bdf454a9de79ca
import layer_6059b59314bdf454a9de79cc as layer_6059b59314bdf454a9de79cc
import layer_6059b59314bdf454a9de79d1 as layer_6059b59314bdf454a9de79d1
import layer_6059b59314bdf454a9de79e5 as layer_6059b59314bdf454a9de79e5
import layer_6059b59314bdf454a9de79d5 as layer_6059b59314bdf454a9de79d5
import layer_6059b59314bdf454a9de79d7 as layer_6059b59314bdf454a9de79d7
import layer_6059b59314bdf454a9de79d9 as layer_6059b59314bdf454a9de79d9
import layer_6059b59314bdf454a9de79db as layer_6059b59314bdf454a9de79db
import layer_6059b59314bdf454a9de79dd as layer_6059b59314bdf454a9de79dd
import layer_6059b59314bdf454a9de79df as layer_6059b59314bdf454a9de79df
import layer_6059b59314bdf454a9de79e1 as layer_6059b59314bdf454a9de79e1
import layer_6059b59314bdf454a9de79e3 as layer_6059b59314bdf454a9de79e3
import layer_6059b59314bdf454a9de79e8 as layer_6059b59314bdf454a9de79e8
import layer_6059b59314bdf454a9de79fc as layer_6059b59314bdf454a9de79fc
import layer_6059b59314bdf454a9de79ec as layer_6059b59314bdf454a9de79ec
import layer_6059b59314bdf454a9de79ee as layer_6059b59314bdf454a9de79ee
import layer_6059b59314bdf454a9de79f0 as layer_6059b59314bdf454a9de79f0
import layer_6059b59314bdf454a9de79f2 as layer_6059b59314bdf454a9de79f2
import layer_6059b59314bdf454a9de79f4 as layer_6059b59314bdf454a9de79f4
import layer_6059b59314bdf454a9de79f6 as layer_6059b59314bdf454a9de79f6
import layer_6059b59314bdf454a9de79f8 as layer_6059b59314bdf454a9de79f8
import layer_6059b59314bdf454a9de79fa as layer_6059b59314bdf454a9de79fa
import layer_6059b59314bdf454a9de79ff as layer_6059b59314bdf454a9de79ff
import layer_6059b59314bdf454a9de7a13 as layer_6059b59314bdf454a9de7a13
import layer_6059b59314bdf454a9de7a03 as layer_6059b59314bdf454a9de7a03
import layer_6059b59314bdf454a9de7a05 as layer_6059b59314bdf454a9de7a05
import layer_6059b59314bdf454a9de7a07 as layer_6059b59314bdf454a9de7a07
import layer_6059b59314bdf454a9de7a09 as layer_6059b59314bdf454a9de7a09
import layer_6059b59314bdf454a9de7a0b as layer_6059b59314bdf454a9de7a0b
import layer_6059b59314bdf454a9de7a0d as layer_6059b59314bdf454a9de7a0d
import layer_6059b59314bdf454a9de7a0f as layer_6059b59314bdf454a9de7a0f
import layer_6059b59314bdf454a9de7a11 as layer_6059b59314bdf454a9de7a11
import layer_6059b59314bdf454a9de7a16 as layer_6059b59314bdf454a9de7a16
import layer_6059b59314bdf454a9de7a2a as layer_6059b59314bdf454a9de7a2a
import layer_6059b59314bdf454a9de7a1a as layer_6059b59314bdf454a9de7a1a
import layer_6059b59314bdf454a9de7a1c as layer_6059b59314bdf454a9de7a1c
import layer_6059b59314bdf454a9de7a1e as layer_6059b59314bdf454a9de7a1e
import layer_6059b59314bdf454a9de7a20 as layer_6059b59314bdf454a9de7a20
import layer_6059b59314bdf454a9de7a22 as layer_6059b59314bdf454a9de7a22
import layer_6059b59314bdf454a9de7a24 as layer_6059b59314bdf454a9de7a24
import layer_6059b59314bdf454a9de7a26 as layer_6059b59314bdf454a9de7a26
import layer_6059b59314bdf454a9de7a28 as layer_6059b59314bdf454a9de7a28
import layer_6059b59314bdf454a9de7a2d as layer_6059b59314bdf454a9de7a2d
import layer_6059b59314bdf454a9de7a41 as layer_6059b59314bdf454a9de7a41
import layer_6059b59314bdf454a9de7a31 as layer_6059b59314bdf454a9de7a31
import layer_6059b59314bdf454a9de7a33 as layer_6059b59314bdf454a9de7a33
import layer_6059b59314bdf454a9de7a35 as layer_6059b59314bdf454a9de7a35
import layer_6059b59314bdf454a9de7a37 as layer_6059b59314bdf454a9de7a37
import layer_6059b59314bdf454a9de7a39 as layer_6059b59314bdf454a9de7a39
import layer_6059b59314bdf454a9de7a3b as layer_6059b59314bdf454a9de7a3b
import layer_6059b59314bdf454a9de7a3d as layer_6059b59314bdf454a9de7a3d
import layer_6059b59314bdf454a9de7a3f as layer_6059b59314bdf454a9de7a3f
import layer_6059b59314bdf454a9de7a44 as layer_6059b59314bdf454a9de7a44
import layer_6059b59314bdf454a9de7a58 as layer_6059b59314bdf454a9de7a58
import layer_6059b59314bdf454a9de7a48 as layer_6059b59314bdf454a9de7a48
import layer_6059b59314bdf454a9de7a4a as layer_6059b59314bdf454a9de7a4a
import layer_6059b59314bdf454a9de7a4c as layer_6059b59314bdf454a9de7a4c
import layer_6059b59314bdf454a9de7a4e as layer_6059b59314bdf454a9de7a4e
import layer_6059b59314bdf454a9de7a50 as layer_6059b59314bdf454a9de7a50
import layer_6059b59314bdf454a9de7a52 as layer_6059b59314bdf454a9de7a52
import layer_6059b59314bdf454a9de7a54 as layer_6059b59314bdf454a9de7a54
import layer_6059b59314bdf454a9de7a56 as layer_6059b59314bdf454a9de7a56
import layer_6059b59314bdf454a9de7a5b as layer_6059b59314bdf454a9de7a5b
import layer_6059b59314bdf454a9de7a5d as layer_6059b59314bdf454a9de7a5d
import layer_6059b59314bdf454a9de7a5f as layer_6059b59314bdf454a9de7a5f
import layer_6059b59314bdf454a9de7a63 as layer_6059b59314bdf454a9de7a63
import layer_6059b59314bdf454a9de7a65 as layer_6059b59314bdf454a9de7a65
import layer_6059b59314bdf454a9de7a67 as layer_6059b59314bdf454a9de7a67
import layer_6059b59314bdf454a9de7a69 as layer_6059b59314bdf454a9de7a69
import layer_6059b59314bdf454a9de7a6b as layer_6059b59314bdf454a9de7a6b
import layer_6059b59314bdf454a9de7a6d as layer_6059b59314bdf454a9de7a6d
import layer_6059b59314bdf454a9de7a6f as layer_6059b59314bdf454a9de7a6f
import layer_6059b59314bdf454a9de7a72 as layer_6059b59314bdf454a9de7a72
import layer_6059b59314bdf454a9de7a76 as layer_6059b59314bdf454a9de7a76
import layer_6059b59314bdf454a9de7a78 as layer_6059b59314bdf454a9de7a78
import layer_6059b59314bdf454a9de7a7a as layer_6059b59314bdf454a9de7a7a
import layer_6059b59314bdf454a9de7a7c as layer_6059b59314bdf454a9de7a7c
import layer_6059b59314bdf454a9de7a7e as layer_6059b59314bdf454a9de7a7e
import layer_6059b59314bdf454a9de7a80 as layer_6059b59314bdf454a9de7a80
import layer_6059b59314bdf454a9de7a82 as layer_6059b59314bdf454a9de7a82
import layer_6059b59314bdf454a9de7a84 as layer_6059b59314bdf454a9de7a84
import layer_6059b59314bdf454a9de7a86 as layer_6059b59314bdf454a9de7a86
import layer_6059b59314bdf454a9de7a8a as layer_6059b59314bdf454a9de7a8a
import layer_6059b59314bdf454a9de7a88 as layer_6059b59314bdf454a9de7a88


def get_layer_object(module):
    for member in getmembers(module):
        if member[1].__module__ == module.__name__:
            return member[1]

def get_loss_sum_fn(list_loss):
    def LossSum(y_true, y_pred):
        loss = 0
        for loss_fn in list_loss:
            loss += loss_fn(y_true, y_pred)
        return loss

    return LossSum

class Model(BaseModel):
    def __init__(self, *args, **kwargs):
        super(Model, self).__init__(*args, **kwargs)
        self.path_weight = file_path + "/weight.hdf5"
        inputs, outputs, losses, labels = self.build_source()
        self.compile(inputs, outputs, losses, labels)

    def build_source(self):
        config_loss = dict()
        volume = 256
        height = 256
        width = 256
        channels = 1
        num_class = 6
        output_channels = 1
        batch_size = 1

        n1_Image = layer_6059b59314bdf454a9de7950.Image(shape=[256, 256, 1])
        n2_Backbone_n1_block1_n1_Conv2D = layer_6059b59314bdf454a9de7956.Conv2D(filters=32, kernel_size=[3, 3], strides=[2, 2], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n1_Image)
        n2_Backbone_n1_block1_n2_BatchNormalization = layer_6059b59314bdf454a9de7958.BatchNormalization()(n2_Backbone_n1_block1_n1_Conv2D)
        n2_Backbone_n1_block1_n3_Activation = layer_6059b59314bdf454a9de795a.Activation(activation='relu')(n2_Backbone_n1_block1_n2_BatchNormalization)
        n2_Backbone_n1_block1_n4_Conv2D = layer_6059b59314bdf454a9de795c.Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n1_block1_n3_Activation)
        n2_Backbone_n1_block1_n5_BatchNormalization = layer_6059b59314bdf454a9de795e.BatchNormalization()(n2_Backbone_n1_block1_n4_Conv2D)
        n2_Backbone_n1_block1_n6_Activation = layer_6059b59314bdf454a9de7960.Activation(activation='relu')(n2_Backbone_n1_block1_n5_BatchNormalization)
        n2_Backbone_n2_Conv2D = layer_6059b59314bdf454a9de7962.Conv2D(filters=128, kernel_size=[1, 1], strides=[2, 2], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n1_block1_n6_Activation)
        n2_Backbone_n3_BatchNormalization = layer_6059b59314bdf454a9de7964.BatchNormalization()(n2_Backbone_n2_Conv2D)
        n2_Backbone_n4_block2_n1_SeparableConv2D = layer_6059b59314bdf454a9de7968.SeparableConv2D(filters=128, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n1_block1_n6_Activation)
        n2_Backbone_n4_block2_n2_BatchNormalization = layer_6059b59314bdf454a9de796a.BatchNormalization()(n2_Backbone_n4_block2_n1_SeparableConv2D)
        n2_Backbone_n4_block2_n3_Activation = layer_6059b59314bdf454a9de796c.Activation(activation='relu')(n2_Backbone_n4_block2_n2_BatchNormalization)
        n2_Backbone_n4_block2_n4_SeparableConv2D = layer_6059b59314bdf454a9de796e.SeparableConv2D(filters=128, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n4_block2_n3_Activation)
        n2_Backbone_n4_block2_n5_BatchNormalization = layer_6059b59314bdf454a9de7970.BatchNormalization()(n2_Backbone_n4_block2_n4_SeparableConv2D)
        n2_Backbone_n4_block2_n6_MaxPooling2D = layer_6059b59314bdf454a9de7972.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='same')(n2_Backbone_n4_block2_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de7975.Add().call).args)
        if num_args == 2:
            n2_Backbone_n5_Add = layer_6059b59314bdf454a9de7975.Add()([n2_Backbone_n3_BatchNormalization, n2_Backbone_n4_block2_n6_MaxPooling2D])
        else:
            n2_Backbone_n5_Add = layer_6059b59314bdf454a9de7975.Add()(*[n2_Backbone_n3_BatchNormalization, n2_Backbone_n4_block2_n6_MaxPooling2D])
        n2_Backbone_n6_Activation = layer_6059b59314bdf454a9de7977.Activation(activation='relu')(n2_Backbone_n5_Add)
        n2_Backbone_n7_Conv2D = layer_6059b59314bdf454a9de7979.Conv2D(filters=256, kernel_size=[1, 1], strides=[2, 2], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n6_Activation)
        n2_Backbone_n8_BatchNormalization = layer_6059b59314bdf454a9de797b.BatchNormalization()(n2_Backbone_n7_Conv2D)
        n2_Backbone_n9_block2_n1_SeparableConv2D = layer_6059b59314bdf454a9de797f.SeparableConv2D(filters=256, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n6_Activation)
        n2_Backbone_n9_block2_n2_BatchNormalization = layer_6059b59314bdf454a9de7981.BatchNormalization()(n2_Backbone_n9_block2_n1_SeparableConv2D)
        n2_Backbone_n9_block2_n3_Activation = layer_6059b59314bdf454a9de7983.Activation(activation='relu')(n2_Backbone_n9_block2_n2_BatchNormalization)
        n2_Backbone_n9_block2_n4_SeparableConv2D = layer_6059b59314bdf454a9de7985.SeparableConv2D(filters=256, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n9_block2_n3_Activation)
        n2_Backbone_n9_block2_n5_BatchNormalization = layer_6059b59314bdf454a9de7987.BatchNormalization()(n2_Backbone_n9_block2_n4_SeparableConv2D)
        n2_Backbone_n9_block2_n6_MaxPooling2D = layer_6059b59314bdf454a9de7989.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='same')(n2_Backbone_n9_block2_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de798c.Add().call).args)
        if num_args == 2:
            n2_Backbone_n10_Add = layer_6059b59314bdf454a9de798c.Add()([n2_Backbone_n8_BatchNormalization, n2_Backbone_n9_block2_n6_MaxPooling2D])
        else:
            n2_Backbone_n10_Add = layer_6059b59314bdf454a9de798c.Add()(*[n2_Backbone_n8_BatchNormalization, n2_Backbone_n9_block2_n6_MaxPooling2D])
        n2_Backbone_n11_Activation = layer_6059b59314bdf454a9de798e.Activation(activation='relu')(n2_Backbone_n10_Add)
        n2_Backbone_n12_Conv2D = layer_6059b59314bdf454a9de7990.Conv2D(filters=728, kernel_size=[1, 1], strides=[2, 2], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_Activation)
        n2_Backbone_n13_BatchNormalization = layer_6059b59314bdf454a9de7992.BatchNormalization()(n2_Backbone_n12_Conv2D)
        n2_Backbone_n14_block2_n1_SeparableConv2D = layer_6059b59314bdf454a9de7996.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n10_Add)
        n2_Backbone_n14_block2_n2_BatchNormalization = layer_6059b59314bdf454a9de7998.BatchNormalization()(n2_Backbone_n14_block2_n1_SeparableConv2D)
        n2_Backbone_n14_block2_n3_Activation = layer_6059b59314bdf454a9de799a.Activation(activation='relu')(n2_Backbone_n14_block2_n2_BatchNormalization)
        n2_Backbone_n14_block2_n4_SeparableConv2D = layer_6059b59314bdf454a9de799c.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n14_block2_n3_Activation)
        n2_Backbone_n14_block2_n5_BatchNormalization = layer_6059b59314bdf454a9de799e.BatchNormalization()(n2_Backbone_n14_block2_n4_SeparableConv2D)
        n2_Backbone_n14_block2_n6_MaxPooling2D = layer_6059b59314bdf454a9de79a0.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='same')(n2_Backbone_n14_block2_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de79a3.Add().call).args)
        if num_args == 2:
            n2_Backbone_n15_Add = layer_6059b59314bdf454a9de79a3.Add()([n2_Backbone_n13_BatchNormalization, n2_Backbone_n14_block2_n6_MaxPooling2D])
        else:
            n2_Backbone_n15_Add = layer_6059b59314bdf454a9de79a3.Add()(*[n2_Backbone_n13_BatchNormalization, n2_Backbone_n14_block2_n6_MaxPooling2D])
        n2_Backbone_n16_block3_n9_Activation = layer_6059b59314bdf454a9de79b7.Activation(activation='relu')(n2_Backbone_n15_Add)
        n2_Backbone_n16_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de79a7.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n16_block3_n9_Activation)
        n2_Backbone_n16_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de79a9.BatchNormalization()(n2_Backbone_n16_block3_n1_SeparableConv2D)
        n2_Backbone_n16_block3_n3_Activation = layer_6059b59314bdf454a9de79ab.Activation(activation='relu')(n2_Backbone_n16_block3_n2_BatchNormalization)
        n2_Backbone_n16_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de79ad.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n16_block3_n3_Activation)
        n2_Backbone_n16_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de79af.BatchNormalization()(n2_Backbone_n16_block3_n4_SeparableConv2D)
        n2_Backbone_n16_block3_n6_Activation = layer_6059b59314bdf454a9de79b1.Activation(activation='relu')(n2_Backbone_n16_block3_n5_BatchNormalization)
        n2_Backbone_n16_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de79b3.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n16_block3_n6_Activation)
        n2_Backbone_n16_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de79b5.BatchNormalization()(n2_Backbone_n16_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de79ba.Add().call).args)
        if num_args == 2:
            n2_Backbone_n17_Add = layer_6059b59314bdf454a9de79ba.Add()([n2_Backbone_n15_Add, n2_Backbone_n16_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n17_Add = layer_6059b59314bdf454a9de79ba.Add()(*[n2_Backbone_n15_Add, n2_Backbone_n16_block3_n8_BatchNormalization])
        n2_Backbone_n18_block3_n9_Activation = layer_6059b59314bdf454a9de79ce.Activation(activation='relu')(n2_Backbone_n17_Add)
        n2_Backbone_n18_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de79be.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n18_block3_n9_Activation)
        n2_Backbone_n18_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de79c0.BatchNormalization()(n2_Backbone_n18_block3_n1_SeparableConv2D)
        n2_Backbone_n18_block3_n3_Activation = layer_6059b59314bdf454a9de79c2.Activation(activation='relu')(n2_Backbone_n18_block3_n2_BatchNormalization)
        n2_Backbone_n18_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de79c4.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n18_block3_n3_Activation)
        n2_Backbone_n18_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de79c6.BatchNormalization()(n2_Backbone_n18_block3_n4_SeparableConv2D)
        n2_Backbone_n18_block3_n6_Activation = layer_6059b59314bdf454a9de79c8.Activation(activation='relu')(n2_Backbone_n18_block3_n5_BatchNormalization)
        n2_Backbone_n18_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de79ca.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n18_block3_n6_Activation)
        n2_Backbone_n18_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de79cc.BatchNormalization()(n2_Backbone_n18_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de79d1.Add().call).args)
        if num_args == 2:
            n2_Backbone_n19_Add = layer_6059b59314bdf454a9de79d1.Add()([n2_Backbone_n17_Add, n2_Backbone_n18_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n19_Add = layer_6059b59314bdf454a9de79d1.Add()(*[n2_Backbone_n17_Add, n2_Backbone_n18_block3_n8_BatchNormalization])
        n2_Backbone_n20_block3_n9_Activation = layer_6059b59314bdf454a9de79e5.Activation(activation='relu')(n2_Backbone_n19_Add)
        n2_Backbone_n20_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de79d5.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n20_block3_n9_Activation)
        n2_Backbone_n20_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de79d7.BatchNormalization()(n2_Backbone_n20_block3_n1_SeparableConv2D)
        n2_Backbone_n20_block3_n3_Activation = layer_6059b59314bdf454a9de79d9.Activation(activation='relu')(n2_Backbone_n20_block3_n2_BatchNormalization)
        n2_Backbone_n20_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de79db.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n20_block3_n3_Activation)
        n2_Backbone_n20_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de79dd.BatchNormalization()(n2_Backbone_n20_block3_n4_SeparableConv2D)
        n2_Backbone_n20_block3_n6_Activation = layer_6059b59314bdf454a9de79df.Activation(activation='relu')(n2_Backbone_n20_block3_n5_BatchNormalization)
        n2_Backbone_n20_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de79e1.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n20_block3_n6_Activation)
        n2_Backbone_n20_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de79e3.BatchNormalization()(n2_Backbone_n20_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de79e8.Add().call).args)
        if num_args == 2:
            n2_Backbone_n21_Add = layer_6059b59314bdf454a9de79e8.Add()([n2_Backbone_n19_Add, n2_Backbone_n20_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n21_Add = layer_6059b59314bdf454a9de79e8.Add()(*[n2_Backbone_n19_Add, n2_Backbone_n20_block3_n8_BatchNormalization])
        n2_Backbone_n22_block3_n9_Activation = layer_6059b59314bdf454a9de79fc.Activation(activation='relu')(n2_Backbone_n21_Add)
        n2_Backbone_n22_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de79ec.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n22_block3_n9_Activation)
        n2_Backbone_n22_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de79ee.BatchNormalization()(n2_Backbone_n22_block3_n1_SeparableConv2D)
        n2_Backbone_n22_block3_n3_Activation = layer_6059b59314bdf454a9de79f0.Activation(activation='relu')(n2_Backbone_n22_block3_n2_BatchNormalization)
        n2_Backbone_n22_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de79f2.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n22_block3_n3_Activation)
        n2_Backbone_n22_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de79f4.BatchNormalization()(n2_Backbone_n22_block3_n4_SeparableConv2D)
        n2_Backbone_n22_block3_n6_Activation = layer_6059b59314bdf454a9de79f6.Activation(activation='relu')(n2_Backbone_n22_block3_n5_BatchNormalization)
        n2_Backbone_n22_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de79f8.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n22_block3_n6_Activation)
        n2_Backbone_n22_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de79fa.BatchNormalization()(n2_Backbone_n22_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de79ff.Add().call).args)
        if num_args == 2:
            n2_Backbone_n23_Add = layer_6059b59314bdf454a9de79ff.Add()([n2_Backbone_n21_Add, n2_Backbone_n22_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n23_Add = layer_6059b59314bdf454a9de79ff.Add()(*[n2_Backbone_n21_Add, n2_Backbone_n22_block3_n8_BatchNormalization])
        n2_Backbone_n24_block3_n9_Activation = layer_6059b59314bdf454a9de7a13.Activation(activation='relu')(n2_Backbone_n23_Add)
        n2_Backbone_n24_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de7a03.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n24_block3_n9_Activation)
        n2_Backbone_n24_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de7a05.BatchNormalization()(n2_Backbone_n24_block3_n1_SeparableConv2D)
        n2_Backbone_n24_block3_n3_Activation = layer_6059b59314bdf454a9de7a07.Activation(activation='relu')(n2_Backbone_n24_block3_n2_BatchNormalization)
        n2_Backbone_n24_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de7a09.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n24_block3_n3_Activation)
        n2_Backbone_n24_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de7a0b.BatchNormalization()(n2_Backbone_n24_block3_n4_SeparableConv2D)
        n2_Backbone_n24_block3_n6_Activation = layer_6059b59314bdf454a9de7a0d.Activation(activation='relu')(n2_Backbone_n24_block3_n5_BatchNormalization)
        n2_Backbone_n24_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de7a0f.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n24_block3_n6_Activation)
        n2_Backbone_n24_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de7a11.BatchNormalization()(n2_Backbone_n24_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de7a16.Add().call).args)
        if num_args == 2:
            n2_Backbone_n25_Add = layer_6059b59314bdf454a9de7a16.Add()([n2_Backbone_n23_Add, n2_Backbone_n24_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n25_Add = layer_6059b59314bdf454a9de7a16.Add()(*[n2_Backbone_n23_Add, n2_Backbone_n24_block3_n8_BatchNormalization])
        n2_Backbone_n26_block3_n9_Activation = layer_6059b59314bdf454a9de7a2a.Activation(activation='relu')(n2_Backbone_n25_Add)
        n2_Backbone_n26_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de7a1a.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n26_block3_n9_Activation)
        n2_Backbone_n26_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de7a1c.BatchNormalization()(n2_Backbone_n26_block3_n1_SeparableConv2D)
        n2_Backbone_n26_block3_n3_Activation = layer_6059b59314bdf454a9de7a1e.Activation(activation='relu')(n2_Backbone_n26_block3_n2_BatchNormalization)
        n2_Backbone_n26_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de7a20.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n26_block3_n3_Activation)
        n2_Backbone_n26_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de7a22.BatchNormalization()(n2_Backbone_n26_block3_n4_SeparableConv2D)
        n2_Backbone_n26_block3_n6_Activation = layer_6059b59314bdf454a9de7a24.Activation(activation='relu')(n2_Backbone_n26_block3_n5_BatchNormalization)
        n2_Backbone_n26_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de7a26.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n26_block3_n6_Activation)
        n2_Backbone_n26_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de7a28.BatchNormalization()(n2_Backbone_n26_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de7a2d.Add().call).args)
        if num_args == 2:
            n2_Backbone_n27_Add = layer_6059b59314bdf454a9de7a2d.Add()([n2_Backbone_n25_Add, n2_Backbone_n26_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n27_Add = layer_6059b59314bdf454a9de7a2d.Add()(*[n2_Backbone_n25_Add, n2_Backbone_n26_block3_n8_BatchNormalization])
        n2_Backbone_n28_block3_n9_Activation = layer_6059b59314bdf454a9de7a41.Activation(activation='relu')(n2_Backbone_n27_Add)
        n2_Backbone_n28_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de7a31.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n28_block3_n9_Activation)
        n2_Backbone_n28_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de7a33.BatchNormalization()(n2_Backbone_n28_block3_n1_SeparableConv2D)
        n2_Backbone_n28_block3_n3_Activation = layer_6059b59314bdf454a9de7a35.Activation(activation='relu')(n2_Backbone_n28_block3_n2_BatchNormalization)
        n2_Backbone_n28_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de7a37.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n28_block3_n3_Activation)
        n2_Backbone_n28_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de7a39.BatchNormalization()(n2_Backbone_n28_block3_n4_SeparableConv2D)
        n2_Backbone_n28_block3_n6_Activation = layer_6059b59314bdf454a9de7a3b.Activation(activation='relu')(n2_Backbone_n28_block3_n5_BatchNormalization)
        n2_Backbone_n28_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de7a3d.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n28_block3_n6_Activation)
        n2_Backbone_n28_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de7a3f.BatchNormalization()(n2_Backbone_n28_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de7a44.Add().call).args)
        if num_args == 2:
            n2_Backbone_n29_Add = layer_6059b59314bdf454a9de7a44.Add()([n2_Backbone_n27_Add, n2_Backbone_n28_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n29_Add = layer_6059b59314bdf454a9de7a44.Add()(*[n2_Backbone_n27_Add, n2_Backbone_n28_block3_n8_BatchNormalization])
        n2_Backbone_n30_block3_n9_Activation = layer_6059b59314bdf454a9de7a58.Activation(activation='relu')(n2_Backbone_n29_Add)
        n2_Backbone_n30_block3_n1_SeparableConv2D = layer_6059b59314bdf454a9de7a48.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n30_block3_n9_Activation)
        n2_Backbone_n30_block3_n2_BatchNormalization = layer_6059b59314bdf454a9de7a4a.BatchNormalization()(n2_Backbone_n30_block3_n1_SeparableConv2D)
        n2_Backbone_n30_block3_n3_Activation = layer_6059b59314bdf454a9de7a4c.Activation(activation='relu')(n2_Backbone_n30_block3_n2_BatchNormalization)
        n2_Backbone_n30_block3_n4_SeparableConv2D = layer_6059b59314bdf454a9de7a4e.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n30_block3_n3_Activation)
        n2_Backbone_n30_block3_n5_BatchNormalization = layer_6059b59314bdf454a9de7a50.BatchNormalization()(n2_Backbone_n30_block3_n4_SeparableConv2D)
        n2_Backbone_n30_block3_n6_Activation = layer_6059b59314bdf454a9de7a52.Activation(activation='relu')(n2_Backbone_n30_block3_n5_BatchNormalization)
        n2_Backbone_n30_block3_n7_SeparableConv2D = layer_6059b59314bdf454a9de7a54.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n30_block3_n6_Activation)
        n2_Backbone_n30_block3_n8_BatchNormalization = layer_6059b59314bdf454a9de7a56.BatchNormalization()(n2_Backbone_n30_block3_n7_SeparableConv2D)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de7a5b.Add().call).args)
        if num_args == 2:
            n2_Backbone_n31_Add = layer_6059b59314bdf454a9de7a5b.Add()([n2_Backbone_n29_Add, n2_Backbone_n30_block3_n8_BatchNormalization])
        else:
            n2_Backbone_n31_Add = layer_6059b59314bdf454a9de7a5b.Add()(*[n2_Backbone_n29_Add, n2_Backbone_n30_block3_n8_BatchNormalization])
        n2_Backbone_n32_Conv2D = layer_6059b59314bdf454a9de7a5d.Conv2D(filters=1024, kernel_size=[1, 1], strides=[2, 2], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n31_Add)
        n2_Backbone_n33_BatchNormalization = layer_6059b59314bdf454a9de7a5f.BatchNormalization()(n2_Backbone_n32_Conv2D)
        n2_Backbone_n34_block4_n1_Activation = layer_6059b59314bdf454a9de7a63.Activation(activation='relu')(n2_Backbone_n31_Add)
        n2_Backbone_n34_block4_n2_SeparableConv2D = layer_6059b59314bdf454a9de7a65.SeparableConv2D(filters=728, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n34_block4_n1_Activation)
        n2_Backbone_n34_block4_n3_BatchNormalization = layer_6059b59314bdf454a9de7a67.BatchNormalization()(n2_Backbone_n34_block4_n2_SeparableConv2D)
        n2_Backbone_n34_block4_n4_Activation = layer_6059b59314bdf454a9de7a69.Activation(activation='relu')(n2_Backbone_n34_block4_n3_BatchNormalization)
        n2_Backbone_n34_block4_n5_SeparableConv2D = layer_6059b59314bdf454a9de7a6b.SeparableConv2D(filters=1024, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n34_block4_n4_Activation)
        n2_Backbone_n34_block4_n6_BatchNormalization = layer_6059b59314bdf454a9de7a6d.BatchNormalization()(n2_Backbone_n34_block4_n5_SeparableConv2D)
        n2_Backbone_n34_block4_n7_MaxPooling2D = layer_6059b59314bdf454a9de7a6f.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='same')(n2_Backbone_n34_block4_n6_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_6059b59314bdf454a9de7a72.Add().call).args)
        if num_args == 2:
            n2_Backbone_n35_Add = layer_6059b59314bdf454a9de7a72.Add()([n2_Backbone_n33_BatchNormalization, n2_Backbone_n34_block4_n7_MaxPooling2D])
        else:
            n2_Backbone_n35_Add = layer_6059b59314bdf454a9de7a72.Add()(*[n2_Backbone_n33_BatchNormalization, n2_Backbone_n34_block4_n7_MaxPooling2D])
        n2_Backbone_n36_block4_n1_Activation = layer_6059b59314bdf454a9de7a76.Activation(activation='relu')(n2_Backbone_n35_Add)
        n2_Backbone_n36_block4_n2_SeparableConv2D = layer_6059b59314bdf454a9de7a78.SeparableConv2D(filters=1536, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n36_block4_n1_Activation)
        n2_Backbone_n36_block4_n3_BatchNormalization = layer_6059b59314bdf454a9de7a7a.BatchNormalization()(n2_Backbone_n36_block4_n2_SeparableConv2D)
        n2_Backbone_n36_block4_n4_Activation = layer_6059b59314bdf454a9de7a7c.Activation(activation='relu')(n2_Backbone_n36_block4_n3_BatchNormalization)
        n2_Backbone_n36_block4_n5_SeparableConv2D = layer_6059b59314bdf454a9de7a7e.SeparableConv2D(filters=2048, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], depth_multiplier=1, activation=None, use_bias=False, depthwise_initializer='glorot_uniform', pointwise_initializer='glorot_uniform', bias_initializer='Zeros', depthwise_regularizer=None, pointwise_regularizer=None, bias_regularizer=None, activity_regularizer=None, depthwise_constraint=None, pointwise_constraint=None, bias_constraint=None)(n2_Backbone_n36_block4_n4_Activation)
        n2_Backbone_n36_block4_n6_BatchNormalization = layer_6059b59314bdf454a9de7a80.BatchNormalization()(n2_Backbone_n36_block4_n5_SeparableConv2D)
        n2_Backbone_n36_block4_n7_MaxPooling2D = layer_6059b59314bdf454a9de7a82.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='same')(n2_Backbone_n36_block4_n6_BatchNormalization)
        n2_Backbone_n37_Activation = layer_6059b59314bdf454a9de7a84.Activation(activation='relu')(n2_Backbone_n36_block4_n7_MaxPooling2D)
        n3_GlobalAveragePooling2D = layer_6059b59314bdf454a9de7a86.GlobalAveragePooling2D()(n2_Backbone_n37_Activation)
        n9_Dropout = layer_6059b59314bdf454a9de7a8a.Dropout(rate=0.5)(n3_GlobalAveragePooling2D)
        n4_Dense = layer_6059b59314bdf454a9de7a88.Dense(units=6, activation='softmax', use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n9_Dropout)
        label = keras.layers.Input(shape=[6])
        loss = keras.losses.CategoricalCrossentropy()(label, n4_Dense)
        



        for key in list(config_loss.keys()):
            if len(config_loss[key]) == 1:
                config_loss[key] = config_loss[key][0]
            elif len(config_loss[key]) > 1:
                config_loss[key] = get_loss_sum_fn(config_loss[key])
            else:
                del config_loss[key]
        inputs = [n1_Image]
        outputs = [n4_Dense]
        losses = [loss]
        labels = [label]

        return inputs, outputs, losses, labels

