from tensorflow.keras.layers import *


class Add(Add):
    pass