from tensorflow.keras.layers import *


class BatchNormalization(BatchNormalization):
    def __init__(self, *args, **kwargs):
        if 'momentum' not in kwargs.keys():
            kwargs['momentum'] = 0.01
        
        super(BatchNormalization, self).__init__(*args, **kwargs)