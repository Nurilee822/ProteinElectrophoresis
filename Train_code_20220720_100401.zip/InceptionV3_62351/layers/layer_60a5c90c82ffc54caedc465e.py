from tensorflow.keras.layers import *


class AveragePooling2D(AveragePooling2D):
    pass