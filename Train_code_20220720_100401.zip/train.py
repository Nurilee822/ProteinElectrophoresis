
import sys
sys.path.append("./library/")


import copy

from deepphi.io.sitk import DeepPhiDataSet
import Color_to_Grayscale_62346.source_code
import Resize_62347.source_code
import Histogram_Equalization_CLAHE___Grayscale_62348.source_code
import Min_Max_Normalization_62349.source_code
import DensNet121_62353.source_code
import VGG19_62350.source_code
import Xception_62352.source_code
import InceptionV3_62351.source_code
import Feature_Merge_62354.source_code


def inference(path_image):
    input_image = DeepPhiDataSet()
    input_image.read_image(path_image)

    output_Color_to_Grayscale_62346 = Color_to_Grayscale_62346.source_code.ColortoGrayscale()(input_image)
    output_Resize_62347 = Resize_62347.source_code.Resize(volume=None, width=256, height=256)(output_Color_to_Grayscale_62346)
    output_Histogram_Equalization_CLAHE___Grayscale_62348 = Histogram_Equalization_CLAHE___Grayscale_62348.source_code.HistogramEqualization__CLAHE_gray(limit=2, kernel_size=7)(output_Resize_62347)
    output_Min_Max_Normalization_62349 = Min_Max_Normalization_62349.source_code.Min_Max_Normalization()(output_Histogram_Equalization_CLAHE___Grayscale_62348)
    output_DensNet121_62353 = DensNet121_62353.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_62349)
    output_VGG19_62350 = VGG19_62350.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_62349)
    output_Xception_62352 = Xception_62352.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_62349)
    output_InceptionV3_62351 = InceptionV3_62351.source_code.Model(label_type='Classification 2D')(output_Min_Max_Normalization_62349)
    output_Feature_Merge_62354 = Feature_Merge_62354.source_code.FeatureMerge()(output_VGG19_62350, output_Xception_62352, output_InceptionV3_62351, output_DensNet121_62353)

    return output_Feature_Merge_62354


if __name__ == "__main__":
    path_image = ""
    result = inference(path_image)
