from tensorflow.keras.layers import *


class Flatten(Flatten):
    pass